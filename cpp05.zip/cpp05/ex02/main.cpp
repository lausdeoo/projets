/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 20:12:47 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/14 16:06:16 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"
#include "ShrubberyCreationForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "PresidentialPardonForm.hpp"


int main(void)
{
    std::string nb1 = "O'neill";
    std::string nb2 = "Carter";
    std::string nf1 = "B13";
    std::string nf2 = "form-765-45X";
    std::string nf3 = "form-95-VF5";
    std::string nf4 = "form-75-PSG9";
    
    std::string nones;
    Bureaucrat *b1 = NULL;
    Bureaucrat *b2 = NULL;
    Bureaucrat *b3 = NULL;

    AForm * f1 = NULL;
    AForm * f2 = NULL;
    AForm * f3 = NULL;
    AForm * f4 = NULL;
    AForm * f5 = NULL;
    AForm * f6 = NULL;
    AForm * f7 = NULL;
    try 
    {
        b1 = new Bureaucrat(nb1,1);
        f1 = new ShrubberyCreationForm(nf2);   // signed 145 // exec 137
        f1->execute(*b1);
        b1->signForm(*f1);
        f1->execute(*b1);
    
        f3 = new RobotomyRequestForm(nf3);
        b1->signForm(*f3);
        f3->execute(*b1);

        f4 = new PresidentialPardonForm(nf4);
        b1->signForm(*f4);
        f4->execute(*b1);
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    std::cout <<std::endl;
    try 
    {
        b2 = new Bureaucrat(nb2,138);
        f6 = new ShrubberyCreationForm("form for form tree");
        b2->signForm(*f6);
        f6->execute(*b2);
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }

    try 
    {
        b3 = new Bureaucrat(nb2,138);
        f7 = new PresidentialPardonForm("No mercy form");
        b3->signForm(*f7);
        f7->execute(*b3);
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    

    delete b1;
    delete b2;
    delete b3;
    delete f1;
    delete f2;
    delete f3;
    delete f4;
    delete f5;
    delete f6;
    delete f7;
}

