/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.hpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 20:27:21 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/25 20:27:28 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
#include "AForm.hpp"
#include <fstream> 

class ShrubberyCreationForm : public AForm
{
    public:
        ShrubberyCreationForm(ShrubberyCreationForm &cpy);
        ShrubberyCreationForm &operator=(ShrubberyCreationForm & rhs);
        virtual ~ShrubberyCreationForm();
        ShrubberyCreationForm(std::string name);
        virtual void execute(Bureaucrat const & executor) const;
    private:
        void draw_shrubbery(void) const;
        ShrubberyCreationForm();
            
};