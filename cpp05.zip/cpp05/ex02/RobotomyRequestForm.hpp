/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.hpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 20:27:45 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/25 20:44:44 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
#include "AForm.hpp"
#include <cstdlib>
#include <unistd.h>


class RobotomyRequestForm : public AForm
{
    public:
        RobotomyRequestForm(RobotomyRequestForm &cpy);
        RobotomyRequestForm &operator=(RobotomyRequestForm & rhs);
        virtual ~RobotomyRequestForm();
        RobotomyRequestForm(std::string name);
        virtual void execute(Bureaucrat const & executor) const;
    private:
        void robotomizing(std::string name) const;
        RobotomyRequestForm();
};