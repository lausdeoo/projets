/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 19:39:27 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/11 17:17:40 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
#include <iostream>
#include <string>
#include "AForm.hpp"
class AForm;

class Bureaucrat
{
    private:
        Bureaucrat();
        const std::string _name;
        int _grade;
    public:
        Bureaucrat &operator=(Bureaucrat const &rhs);
        Bureaucrat(Bureaucrat const &cpy);
        ~Bureaucrat();
        std::string getName()const;
        int getGrade()const;
        Bureaucrat(std::string name, int grade);
        void increaseGrade();
        void decreaseGrade();
        void signForm(AForm &AForm);
        class GradeTooHighException : public std::exception
        {
            private:
                std::string _msg_exception;
            public:
                GradeTooHighException(std::string name);
                virtual ~GradeTooHighException() throw(){}
                virtual const char * what() const throw();
        };
        class GradeTooLowException : public std::exception
        {
            private:
                std::string _msg_exception;
            public:
                GradeTooLowException(std::string name);
                virtual ~GradeTooLowException() throw(){}
                virtual const char * what() const throw();
        };
};

std::ostream &operator<<(std::ostream &o, Bureaucrat const &rhs);
