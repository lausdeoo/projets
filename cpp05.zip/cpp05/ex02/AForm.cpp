/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AForm.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 20:25:32 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/14 15:56:06 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "AForm.hpp"

AForm::AForm():_name(""),_isSigned(false),_sign_grade(50),_exec_grade(50)
{   
}

AForm::AForm(std::string name, int sign_grade, int exec_grade):_name(name),_sign_grade(sign_grade),_exec_grade(exec_grade)
{
    if (sign_grade > 150  || exec_grade > 150)
        throw GradeTooLowException();
    if (sign_grade < 1  || exec_grade < 1)
        throw GradeTooHighException();
    this->_isSigned = false;
}
AForm::~AForm()
{
    
}
AForm::AForm(const AForm &cpy):_name(cpy._name),_sign_grade(cpy._sign_grade),_exec_grade(cpy._exec_grade)
{
    this->_isSigned = cpy._isSigned;
}
AForm &AForm::operator=(const AForm &rhs)
{
    if (this != &rhs)
    {
        this->_isSigned = rhs._isSigned;
    }
    return *this;
}

AForm::GradeTooHighException::GradeTooHighException()
{
    
}

AForm::GradeTooLowException::GradeTooLowException()
{
    
}

bool AForm::beSigned(Bureaucrat *bureaucrat)
{
    if (bureaucrat->getGrade() <= this->getSignedGrade())
    {
        this->_isSigned = true;
        return true;
    }
    else
    {
        std::cout << bureaucrat->getName() <<" couldn’t sign " << this->getName() << " because his grade is over " << this->getSignedGrade() << std::endl;
        throw AForm::GradeTooLowException();
    }
    return false; 
}

const char *AForm::GradeTooHighException::what() const throw()
{
    return ("GradeTooHighException");
}

const char *AForm::GradeTooLowException::what() const throw()
{
    return ("GradeTooLowException");
}

AForm::GradeTooHighException::~GradeTooHighException() throw() {}
AForm::GradeTooLowException::~GradeTooLowException() throw() {}

std::string AForm::getName(void) const
{
    return this->_name;
}
int AForm::getSignedGrade(void) const
{
    return this->_sign_grade;
}
int AForm::getExecdGrade(void) const
{
    return this->_exec_grade;
}
bool AForm::getIsSigned(void) const
{
    return this->_isSigned;
}

void AForm::setSigned(bool is_signed)
{
    this->_isSigned = is_signed;
}

std::ostream &operator<<(std::ostream &o, AForm const &rhs)
{
    o << "Name           : " << rhs.getName() <<std::endl;
    o << "Signed grade   : " << rhs.getSignedGrade() <<std::endl;
    o << "Executed grade : " << rhs.getExecdGrade() <<std::endl;
    if (rhs.getIsSigned())
        o << "Is signed      : true" <<std::endl;
    else
        o << "Is signed      : false" <<std::endl;
    return o;
}




