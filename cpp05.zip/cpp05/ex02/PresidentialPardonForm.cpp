/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.cpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 20:26:27 by idioumas          #+#    #+#             */
/*   Updated: 2025/09/01 16:59:25 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "PresidentialPardonForm.hpp"

PresidentialPardonForm::PresidentialPardonForm(PresidentialPardonForm &cpy)
{
    this->setSigned(cpy.getIsSigned());
}
PresidentialPardonForm &PresidentialPardonForm::operator=(PresidentialPardonForm & rhs)
{
    if (this != &rhs)
        this->setSigned(rhs.getIsSigned());
    return *this;
}
PresidentialPardonForm::~PresidentialPardonForm()
{
    
}
PresidentialPardonForm::PresidentialPardonForm(std::string name):AForm(name, 25, 5)
{
    
}
void PresidentialPardonForm::givePresidentialPardon(std::string name) const
{
    std::cout << name << " has been pardoned by Zaphod Beeblebrox" << std::endl;
}
void PresidentialPardonForm::execute(Bureaucrat const & executor) const
{
    if (this->getIsSigned() == false)
    {
        std::cout << this->getName() <<" form must be signed before being execute" << std::endl;
        return ;
    }
    if (executor.getGrade() > this->getExecdGrade())
    {
        std::cout << executor.getName() << " executor's grade is too low" << std::endl;
        throw AForm::GradeTooLowException();
    }
    else
        this->givePresidentialPardon(executor.getName());
}

PresidentialPardonForm::PresidentialPardonForm()
{
    
}