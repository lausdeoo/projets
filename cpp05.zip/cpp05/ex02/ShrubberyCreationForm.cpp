/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ShrubberyCreationForm.cpp                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 20:30:50 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/25 20:23:01 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ShrubberyCreationForm.hpp"

ShrubberyCreationForm::ShrubberyCreationForm(){}

ShrubberyCreationForm::ShrubberyCreationForm(std::string name) : AForm(name,145,137)
{
    
}

ShrubberyCreationForm::ShrubberyCreationForm(ShrubberyCreationForm &cpy):AForm(cpy.getName(),cpy.getSignedGrade(),cpy.getExecdGrade())
{
    
}
ShrubberyCreationForm::~ShrubberyCreationForm()
{
    
}
ShrubberyCreationForm &ShrubberyCreationForm::operator=(ShrubberyCreationForm & rhs)
{
    if (this != &rhs)
    {
        this->setSigned(rhs.getIsSigned());   
    }
    return *this;
}

void ShrubberyCreationForm::draw_shrubbery(void) const
{
    std::string filename = this->getName() + "_shrubbery"; 
    std::ofstream writter(filename.c_str());
    if(writter.is_open() == false)
    {
        std::cerr << "Error file creation" <<std::endl;
        return;   
    }
    
    writter << "        *        " << std::endl;
    writter << "       ***       " << std::endl;
    writter << "      *****      " << std::endl;
    writter << "     *******     " << std::endl;
    writter << "    *********    " << std::endl;
    writter << "   ***********   " << std::endl;
    writter << "        ||       " << std::endl;
    writter << "        ||       " << std::endl; 
    writter.close();
    std::cout << "Form : "<< this->getName() << " have been executed with success" << std::endl;
}

void ShrubberyCreationForm::execute(Bureaucrat const & executor) const
{
    if (this->getIsSigned() == false)
    {
        std::cout << this->getName() <<" form must be signed before being execute" << std::endl;
        return ;
    }
    if (executor.getGrade() > this->getExecdGrade())
    {
        std::cout << executor.getName() << " executor's grade is too low" << std::endl;
        throw AForm::GradeTooLowException();
    }
    else
        this->draw_shrubbery();
}