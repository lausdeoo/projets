/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AForm.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 20:23:50 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/25 21:28:09 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#pragma once
#include <iostream>
#include <exception>
#include "Bureaucrat.hpp"
class Bureaucrat;

class AForm
{
    private:
        const std::string _name;
        bool _isSigned;
        const int _sign_grade;
        const int _exec_grade;
    public:
        AForm();
        AForm(std::string name, int _min_sign_grade, int _min_exec_grade);
        virtual ~AForm();
        AForm(const AForm &cpy);
        AForm &operator=(const AForm &rhs);
        std::string getName(void)const;
        int getSignedGrade(void)const;
        int getExecdGrade(void)const;
        bool getIsSigned(void)const;
        void setSigned(bool is_signed);
        virtual void execute(Bureaucrat const & executor) const = 0;
        bool beSigned(Bureaucrat *Bureaucrat);
        class GradeTooHighException : public std::exception
        {
            public:
                GradeTooHighException();
                virtual const char *what() const throw();
                virtual ~GradeTooHighException() throw(); 
        };
        class GradeTooLowException : public std::exception
        {
            public:
                GradeTooLowException();
                virtual const char *what() const throw();
                virtual ~GradeTooLowException() throw(); 
        };

    
};

std::ostream &operator<<(std::ostream &o, const AForm &rhs);