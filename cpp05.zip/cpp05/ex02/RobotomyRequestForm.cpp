/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   RobotomyRequestForm.cpp                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 20:32:25 by idioumas          #+#    #+#             */
/*   Updated: 2025/09/01 16:22:19 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

 #include "RobotomyRequestForm.hpp"

RobotomyRequestForm::RobotomyRequestForm(RobotomyRequestForm &cpy)
{
    this->setSigned(cpy.getIsSigned());
}
RobotomyRequestForm &RobotomyRequestForm::operator=(RobotomyRequestForm & rhs)
{
    if (this != &rhs)
        this->setSigned(rhs.getIsSigned());
    return *this;
}
RobotomyRequestForm::~RobotomyRequestForm()
{
    
}
RobotomyRequestForm::RobotomyRequestForm(std::string name):AForm(name, 75, 45)
{
    
}
void RobotomyRequestForm::robotomizing(std::string name_executor) const
{
    std::cout << "Drilling noise"<<std::endl;
    for (int i = 0; i < 4;i++)
    {
        usleep(1000000);
        std::cout << "."<< std::endl;
        
    }
    std::cout << std::endl;
    srand(time(0));
    if (rand()%2 == 0)
        std::cout << name_executor << " has been robotomized with succcess" << std::endl;
    else
        std::cout << name_executor << "'s robotomizing failed" << std::endl;
}

void RobotomyRequestForm::execute(Bureaucrat const & executor) const
{
    if (this->getIsSigned() == false)
    {
        std::cout << this->getName() <<" form must be signed before being execute" << std::endl;
        return ;
    }
    if (executor.getGrade() > this->getExecdGrade())
    {
        std::cout << executor.getName() << " executor's grade is too low" << std::endl;
        throw AForm::GradeTooLowException();
    }
    else
        this->robotomizing(executor.getName());
}

RobotomyRequestForm::RobotomyRequestForm()
{
    
}