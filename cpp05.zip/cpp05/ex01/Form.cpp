/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Form.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 20:25:32 by idioumas          #+#    #+#             */
/*   Updated: 2025/08/25 16:18:56 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "Form.hpp"

Form::Form():_name(""),_isSigned(false),_sign_grade(50),_exec_grade(50)
{   
}

Form::Form(std::string name, int sign_grade, int exec_grade):_name(name),_sign_grade(sign_grade),_exec_grade(exec_grade)
{
    if (sign_grade > 150  || exec_grade > 150)
        throw GradeTooHighException();
    if (sign_grade < 1  || exec_grade < 1)
        throw GradeTooLowException();
    this->_isSigned = false;
}
Form::~Form()
{
    
}
Form::Form(const Form &cpy):_name(cpy._name),_sign_grade(cpy._sign_grade),_exec_grade(cpy._exec_grade)
{
    this->_isSigned = cpy._isSigned;
}
Form &Form::operator=(const Form &rhs)
{
    if (this != &rhs)
    {
        this->_isSigned = rhs._isSigned;
    }
    return *this;
}

Form::GradeTooHighException::GradeTooHighException()
{
    
}

Form::GradeTooLowException::GradeTooLowException()
{
    
}

bool Form::beSigned(Bureaucrat *bureaucrat)
{
    if (bureaucrat->getGrade() <= this->getSignedGrade())
    {
        this->_isSigned = true;
        return true;
    }
    else
    {
        std::cout << bureaucrat->getName() <<" couldn’t sign " << this->getName() << " because his grade is over " << this->getSignedGrade() << std::endl;
        throw Form::GradeTooLowException();
    }
    return false; 
}

const char *Form::GradeTooHighException::what() const throw()
{
    return ("Form::GradeTooHighException");
}

const char *Form::GradeTooLowException::what() const throw()
{
    return ("Form::GradeTooLowException");
}

Form::GradeTooHighException::~GradeTooHighException() throw() {}
Form::GradeTooLowException::~GradeTooLowException() throw() {}

std::string Form::getName(void) const
{
    return this->_name;
}
int Form::getSignedGrade(void) const
{
    return this->_sign_grade;
}
int Form::getExecdGrade(void) const
{
    return this->_exec_grade;
}
bool Form::getIsSigned(void) const
{
    return this->_isSigned;
}

std::ostream &operator<<(std::ostream &o, Form const &rhs)
{
    o << "Name           : " << rhs.getName() <<std::endl;
    o << "Signed grade   : " << rhs.getSignedGrade() <<std::endl;
    o << "Executed grade : " << rhs.getExecdGrade() <<std::endl;
    if (rhs.getIsSigned())
        o << "Is signed      : true" <<std::endl;
    else
        o << "Is signed      : false" <<std::endl;
    return o;
}


