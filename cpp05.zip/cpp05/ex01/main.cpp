/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yucheng <yucheng@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 20:12:47 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/17 21:09:40 by yucheng          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"
#include "Form.hpp"

int main(void)
{
    std::string nb1 = "O'neill";
    std::string nb2 = "Carter";
    std::string nf1 = "B13";
    std::string nf2 = "form-765-45X";
    
    Bureaucrat *b1 = NULL;
    Bureaucrat *b2 = NULL;
    
    Form * f1 = NULL;
    Form * f2 = NULL;


    try
    {
        Form bad_form1("Bad form 1" ,-45,45);   // Unauthorized grade is too must be between 1 and 150; 
    }
    catch(Form::GradeTooLowException  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }

    try
    {
        Form bad_form1("Bad form 2",360,45);   // Unauthorized grade is too must be between 1 and 150; 
    }
    catch(Form::GradeTooHighException  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    std::cout << std::endl;
    std::cout << std::endl;
    
    try
    {
        b1 = new Bureaucrat(nb1,100);
        b2 = new Bureaucrat(nb2,1);

        std::cout << *b1 << std::endl;
        std::cout << *b2 << std::endl;
        
        f1 = new Form(nf1,45,96);
        f2 = new Form(nf2,5,96);
        
        std::cout << *f1 << std::endl;
        
        b2->signForm(*f1);
        std::cout << std::endl;
        b2->signForm(*f1);
        b1->signForm(*f1);

        std::cout << *f2 << std::endl;
        b1->signForm(*f2);
        std::cout << std::endl;


        
        
    }
    catch(Bureaucrat::GradeTooHighException  &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Bureaucrat::GradeTooLowException  &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Form::GradeTooHighException  &e)
    {
        std::cout << e.what() << std::endl;   
    }
    catch(Form::GradeTooLowException  &e)
    {
        std::cout << e.what() << std::endl;  
    }
    catch(std::exception  &e)
    {
        std::cout << e.what() << std::endl;  
    }

    delete b1;
    delete b2;
    delete f1;
    delete f2;
}

