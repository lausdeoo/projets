/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.hpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yucheng <yucheng@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 19:39:27 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/17 21:08:29 by yucheng          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
#include <iostream>
#include <string>
#include "Form.hpp"

class Form;

class Bureaucrat
{
    private:
        Bureaucrat();
        const std::string _name;
        int _grade;
    public:
        int youcanseeme;
        Bureaucrat &operator=(Bureaucrat const &rhs);
        Bureaucrat(Bureaucrat const &cpy);
        ~Bureaucrat();
        std::string getName()const;
        int getGrade()const;
        Bureaucrat(std::string name, int grade);
        void increaseGrade();
        void decreaseGrade();
        void signForm(Form &form);
        class GradeTooHighException : public std::exception
        {
            private:
                std::string _msg_exception;
            public:
                GradeTooHighException(std::string name);
                virtual ~GradeTooHighException() throw(){}
                virtual const char * what() const throw();
        };
        class GradeTooLowException : public std::exception
        {
            private:
                std::string _msg_exception;
            public:
                GradeTooLowException(std::string name);
                virtual ~GradeTooLowException() throw(){}
                virtual const char * what() const throw();
        };
};

std::ostream &operator<<(std::ostream &o, Bureaucrat const &rhs);
