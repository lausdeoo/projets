/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yucheng <yucheng@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 20:12:47 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/17 20:56:37 by yucheng          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"


int main(void)
{
    std::string name1 = "Cahill";
    std::string name2 = "Nanami";
    std::string name3 = "Sean";
    std::string name4 = "Pearson";
    
    Bureaucrat * b1 = NULL;
    Bureaucrat * b2 = NULL;
    Bureaucrat * b3 = NULL;
    Bureaucrat * b4 = NULL;
    
    try
    {
        b1 = new Bureaucrat(name1, 0); // wrong grade
    }
    catch(Bureaucrat::GradeTooLowException &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Bureaucrat::GradeTooHighException &e)
    {
        std::cout << e.what() << std::endl;
    }

    try
    {
        b2 = new Bureaucrat(name2, 151); // wrong grade
    }
    catch(Bureaucrat::GradeTooLowException &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Bureaucrat::GradeTooHighException &e)
    {
        std::cout << e.what() << std::endl;
    }
    // custom grade
    try
    {
        b3 = new Bureaucrat(name3, 4); 
        std::cout << *b3 << std::endl;
        b3->increaseGrade();
        std::cout << *b3 << std::endl;
        b3->increaseGrade();
        std::cout << *b3 << std::endl;
        b3->increaseGrade();
        std::cout << *b3 << std::endl;
        b3->increaseGrade();
        std::cout << *b3 << std::endl;
        b3->increaseGrade();
    }
    catch(Bureaucrat::GradeTooLowException &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Bureaucrat::GradeTooHighException &e)
    {
        std::cout << e.what() << std::endl;
    }

    try
    {
        b4 = new Bureaucrat(name4, 146);
        b4->decreaseGrade();
        std::cout << *b4 << std::endl;
        b4->decreaseGrade();
        std::cout << *b4 << std::endl;
        b4->decreaseGrade();
        std::cout << *b4 << std::endl;
        b4->decreaseGrade();
        std::cout << *b4 << std::endl;
        b4->decreaseGrade();
        std::cout << *b4 << std::endl;
    }
    catch(Bureaucrat::GradeTooLowException &e)
    {
        std::cout << e.what() << std::endl;
    }
    catch(Bureaucrat::GradeTooHighException &e)
    {
        std::cout << e.what() << std::endl;
    }

    delete b1;
    delete b2;
    delete b3;
    delete b4;
}

