/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 19:25:01 by idioumas          #+#    #+#             */
/*   Updated: 2025/09/01 21:27:20 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#pragma once
#include "PresidentialPardonForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "ShrubberyCreationForm.hpp"

class Intern
{
    private:
    
    public:
        Intern();
        Intern(Intern & cpy);
        Intern &operator=(Intern &rhs);
        AForm *makeForm(std::string form, std::string target);
        ~Intern();
        class NonExistingFormException : public std::exception
        {
            public:
                NonExistingFormException();
                virtual const char *what() const throw();
                virtual ~NonExistingFormException() throw(); 
        };
};


