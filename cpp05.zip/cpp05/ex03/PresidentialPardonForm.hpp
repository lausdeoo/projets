/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PresidentialPardonForm.hpp                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/24 20:26:34 by idioumas          #+#    #+#             */
/*   Updated: 2025/09/01 21:51:10 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#pragma once
#include "AForm.hpp"

class PresidentialPardonForm : public AForm
{
    private:
        PresidentialPardonForm();
        void givePresidentialPardon(std::string name) const;
    public:
        ~PresidentialPardonForm();
        PresidentialPardonForm(PresidentialPardonForm &cpy);
        PresidentialPardonForm &operator=(PresidentialPardonForm & rhs);
        PresidentialPardonForm(std::string name);
        void execute(Bureaucrat const & executor) const;
};


