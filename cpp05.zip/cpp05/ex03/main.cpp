/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 20:12:47 by idioumas          #+#    #+#             */
/*   Updated: 2025/09/02 16:27:57 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"
#include "ShrubberyCreationForm.hpp"
#include "RobotomyRequestForm.hpp"
#include "PresidentialPardonForm.hpp"
#include "Intern.hpp"

int main(void)
{
    Intern intern;
    AForm * f0 = NULL;
    AForm * f1 = NULL;
    AForm * f2 = NULL;
    AForm * fx = NULL;

    Bureaucrat *b0;
    try
    {
        f0 = intern.makeForm("PresidentialPardonForm","Expension");
        f1 = intern.makeForm("RobotomyRequestForm","Expension");
        f2 = intern.makeForm("ShrubberyCreationForm","Expension");
    }
    catch (Intern::NonExistingFormException &e)
    {
        std::cout << e.what() << std::endl;
    }

    try
    {
        b0 = new Bureaucrat("Harvey", 1);
        b0->signForm(*f0);
        f0->execute(*b0);
    }
    catch (std::exception &e)
    {
        std::cout << e.what() << std::endl;
    }

    try
    {
        fx = intern.makeForm("newfalseform","Expension");
    }
    catch (Intern::NonExistingFormException &e)
    {
        std::cout << e.what() << std::endl;
    }
    
    delete f0;
    delete f1;
    delete f2;
    delete fx;
    delete b0;
}

