/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Intern.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yucheng <yucheng@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 19:28:03 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/17 21:19:17 by yucheng          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "Intern.hpp"
#include <vector>


Intern::Intern()
{
    
}


Intern::Intern(Intern & cpy){
    (void)cpy;
  }
Intern &Intern::operator=(Intern &rhs)
{
    (void)rhs;
    return *this;
}

const char *Intern::NonExistingFormException::what() const throw()
{
    return ("NonExistingFormException");   
}
Intern::NonExistingFormException::NonExistingFormException() {}
Intern::NonExistingFormException::~NonExistingFormException() throw() {}

AForm *Intern::makeForm(std::string form, std::string target)
{ 
    int i;
    std::string forms[3] = {"PresidentialPardonForm", "RobotomyRequestForm", "ShrubberyCreationForm"};
     
    for ( i = 0; i < 3;i++)
    {
        if (forms[i].compare(form) == 0)
            break;
    }

    switch (i)
    {
        case  0:
            std::cout << "Intern creates "<< form << " at targeted " << target <<std::endl;
            return new PresidentialPardonForm(form);
        case  1:
            std::cout << "Intern creates "<< form << " at targeted " << target <<std::endl;
            return new RobotomyRequestForm(form);
        case  2:
            std::cout << "Intern creates "<< form << " at targeted " << target <<std::endl;
            return new ShrubberyCreationForm(form);
        default:
            throw NonExistingFormException();
    }
}

Intern::~Intern(){}