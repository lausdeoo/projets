/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Bureaucrat.cpp                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idioumas <idioumas@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 19:38:42 by idioumas          #+#    #+#             */
/*   Updated: 2025/10/14 16:01:32 by idioumas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Bureaucrat.hpp"

Bureaucrat::Bureaucrat(){}
Bureaucrat::Bureaucrat(Bureaucrat const &cpy):_name(cpy._name){
    this->_grade = cpy._grade;
}

Bureaucrat &Bureaucrat::operator=(Bureaucrat const &rhs)
{
    if (this != &rhs) { 
        this->_grade = rhs._grade;
    }
    return *this;
}
Bureaucrat::~Bureaucrat(){}

const char *Bureaucrat::GradeTooHighException::what() const throw()
{
    return (this->_msg_exception.c_str());
}

const char *Bureaucrat::GradeTooLowException::what() const throw()
{
    return (this->_msg_exception.c_str());
}

Bureaucrat::GradeTooLowException::GradeTooLowException(std::string name):_msg_exception("GradeTooLowException : "+ name +"'s  grade is over 150")
{

}
Bureaucrat::GradeTooHighException::GradeTooHighException(std::string name):_msg_exception("GradeTooHighException : "+ name +"'s grade is under 1")
{

}

Bureaucrat::Bureaucrat(std::string name, int grade):_name(name)
{
    if (grade < 1)
        throw Bureaucrat::GradeTooHighException(name);
    if (grade > 150)
        throw Bureaucrat::GradeTooLowException(name);
    this->_grade = grade;
}
void Bureaucrat::signForm(AForm &AForm)
{
    if (AForm.getIsSigned() == true)
        std::cout << AForm.getName() << " is already signed" << std::endl;
    else if(AForm.beSigned(this) == true)
        std::cout << this->getName() << " signed " << AForm.getName() << std::endl;
    else
        std::cout <<this->getName() << " couldn’t sign " << AForm.getName() <<" because " << "bureaucrat's grade isn't hight enough." <<std::endl;
}
std::string Bureaucrat::getName()const
{
    return this->_name;
}

int Bureaucrat::getGrade()const
{
    return this->_grade;
}

void Bureaucrat::increaseGrade()
{
    if (this->getGrade() - 1 < 1)
        throw Bureaucrat::GradeTooHighException(this->getName());
    this->_grade--;
}

void Bureaucrat::decreaseGrade()
{
    if (this->getGrade() + 1 > 150)
        throw Bureaucrat::GradeTooLowException(this->getName());
    this->_grade++;
}
std::ostream &operator<<(std::ostream &o, Bureaucrat const &rhs)
{
    o << rhs.getName() <<", bureaucrat grade " << rhs.getGrade();
    return o;
}