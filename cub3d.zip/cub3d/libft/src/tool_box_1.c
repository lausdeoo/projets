/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tool_box_1.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/05 14:49:27 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 11:15:39 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

char	*convert_tohex(unsigned long int addr, char *base)
{
	char				*dest;
	int					i;
	unsigned long int	nbr;

	nbr = addr;
	i = taille_nbr_un(addr, 16);
	dest = malloc(i + 1);
	if (!dest)
		return (NULL);
	dest[i] = '\0';
	while (i-- > 0)
	{
		dest[i] = base[nbr % 16];
		nbr /= 16;
	}
	return (dest);
}

int	taille_nbr(int nbr, int taille_base)
{
	int	cpt;

	if (nbr == 0)
		return (1);
	cpt = 0;
	while (nbr != 0)
	{
		nbr /= taille_base;
		cpt++;
	}
	return (cpt);
}

int	taille_nbr_un(unsigned long int nbr, int taille_base)
{
	int	cpt;

	if (nbr == 0)
		return (1);
	cpt = 0;
	while (nbr != 0)
	{
		nbr /= taille_base;
		cpt++;
	}
	return (cpt);
}

void	decr_and_put(int *cpt, char c, int *width)
{
	put_char_cpt(cpt, c);
	(*width)--;
}

int	is_str0(const char *str)
{
	if (str[0] == '0' && !str[1])
		return (1);
	return (0);
}
