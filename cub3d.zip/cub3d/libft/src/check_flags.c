/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_flags.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/04 13:51:18 by tcros             #+#    #+#             */
/*   Updated: 2024/12/17 20:05:39 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	check_flags(t_flags *flags, const char *str, int i)
{
	while ((!ft_isalnum((int)str[i]) || str[i] == '0' )
		&& str[i] != '.' && str[i] != '%')
	{
		if (str[i] == '-')
			flags->bol_min = 1;
		if (str[i] == '0')
			flags->bol_0 = 1;
		if (str[i] == '#')
			flags->bol_die = 1;
		if (str[i] == ' ')
			flags->bol_space = 1;
		if (str[i] == '+')
			flags->bol_plu = 1;
		i++;
	}
	while (ft_isdigit((int)str[i]))
	{
		flags->width = 10 * flags->width + str[i] - '0';
		i++;
	}
	if (str[i] == '.')
		check_precision(flags, str, &i);
	flags->c = str[i];
	recheck_flags(flags);
}

void	recheck_flags(t_flags *flags)
{
	if (is_incharset("sc%", flags->c))
		flags->bol_0 = 0;
	if (is_incharset("cp%", flags->c))
	{
		flags->bol_poi = 0;
		flags->precision = -1;
	}
	if (is_incharset("csdi%", flags->c))
		flags->bol_die = 0;
	if (is_incharset("csuxX%", flags->c))
		flags->bol_space = 0;
	if (is_incharset("csuxX%", flags->c))
		flags->bol_plu = 0;
	if (flags->c == 'p')
		flags->bol_die = 1;
	if (is_incharset("diu", flags->c) && flags->bol_poi)
		flags->bol_0 = 0;
	if (flags->c == '%')
		flags->bol_min = 0;
	if (flags->c == 'u')
		flags->signe = 0;
}

int	is_incharset(const char *cset, char c)
{
	int	i;

	i = 0;
	while (cset[i])
		if (cset[i++] == c)
			return (1);
	return (0);
}

void	check_precision(t_flags *flags, const char *str, int *i)
{
	flags->bol_poi = 1;
	flags->precision = 0;
	*i += 1;
	while (ft_isdigit(str[*i]))
	{
		flags->precision = 10 * flags->precision + str[*i] - '0';
		*i += 1;
	}
}

void	ft_putnbrun_fd(unsigned long int n, int fd)
{
	if (n < 10)
	{
		ft_putchar_fd(n + '0', fd);
	}
	else
	{
		ft_putnbrun_fd(n / 10, fd);
		ft_putchar_fd((n % 10) + '0', fd);
	}
}
