/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/04 11:51:57 by tcros             #+#    #+#             */
/*   Updated: 2024/12/11 16:19:35 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	init_flags(t_flags *flags)
{
	flags->bol_min = 0;
	flags->bol_0 = 0;
	flags->bol_poi = 0;
	flags->bol_die = 0;
	flags->bol_space = 0;
	flags->bol_plu = 0;
	flags->width = 0;
	flags->precision = -1;
	flags->signe = 0;
}

void	start_format(const char *str, int *i, va_list ptr, int *cpt)
{
	t_flags	flags;

	(*i)++;
	init_flags(&flags);
	check_flags(&flags, str, (*i));
	put_all(&flags, ptr, cpt);
	while (!is_incharset("cspdiuxX%", str[*i]))
		(*i)++;
}

int	ft_printf(const char *str, ...)
{
	va_list	ptr;
	int		i;
	int		cpt;

	cpt = 0;
	if (!str)
		return (-1);
	i = 0;
	va_start(ptr, str);
	while (str[i])
	{
		if (str[i] == '%')
			start_format(str, &i, ptr, &cpt);
		else
		{
			cpt++;
			ft_putchar_fd(str[i], 1);
		}
		i++;
	}
	va_end(ptr);
	return (cpt);
}
