/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_args_1.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/04 15:49:09 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 11:55:13 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	put_all(t_flags *flags, va_list ptr, int *cpt)
{
	if (flags->c != '%')
		put_flags(flags, ptr, cpt);
	if (flags->c == 'c')
		put_format_c(flags, va_arg(ptr, int), cpt);
	else if (flags->c == 's')
		put_format_s(flags, va_arg(ptr, const char *), cpt);
	else if (flags->c == 'p')
		put_format_p(flags, va_arg(ptr, unsigned long int), cpt);
	else if (flags->c == 'd')
		put_format_d(flags, va_arg(ptr, int), cpt);
	else if (flags->c == 'i')
		put_format_i(flags, va_arg(ptr, int), cpt);
	else if (flags->c == 'u')
		put_format_u(flags, va_arg(ptr, unsigned int), cpt);
	else if (flags->c == 'x')
		put_format_x(flags, va_arg(ptr, unsigned int), cpt);
	else if (flags->c == 'X')
		put_format_xmaj(flags, va_arg(ptr, unsigned int), cpt);
	else if (flags->c == '%')
		put_format_perc(cpt);
}

void	put_flags(t_flags *flags, va_list ptr, int *cpt)
{
	int		i;
	va_list	cpy;
	char	*hstr;

	hstr = "0x";
	if (flags->c == 'X')
		hstr = "0X";
	va_copy(cpy, ptr);
	i = width_to_put(flags, cpy);
	if (flags->width == 0)
		flags->bol_min = 0;
	if (flags->bol_die && (flags->precision >= flags->width))
		put_str_cpt(cpt, hstr);
	put_flags_bor(flags, i, cpt);
	if (flags->bol_die && !flags->bol_0 && !flags->bol_poi && flags->c == 'p')
		put_str_cpt(cpt, hstr);
	va_end(cpy);
}

void	put_char_cpt(int *cpt, char c)
{
	(*cpt)++;
	ft_putchar_fd(c, 1);
}
