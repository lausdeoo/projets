/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/13 15:45:07 by tcros             #+#    #+#             */
/*   Updated: 2024/11/13 16:08:51 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dest, const char *src, size_t n)
{
	size_t	ldest;
	size_t	j;
	size_t	lsrc;

	ldest = ft_strlen(dest);
	lsrc = ft_strlen(src);
	j = 0;
	if (n <= ldest)
		return (lsrc + n);
	if (n != 0)
	{
		while (src[j] && ldest + j < n - 1)
		{
			dest[ldest + j] = src[j];
			j++;
		}
		dest[ldest + j] = '\0';
	}
	return (lsrc + ldest);
}
