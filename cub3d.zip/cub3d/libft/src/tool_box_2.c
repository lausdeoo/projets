/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tool_box_2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/10 13:52:19 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 11:07:12 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	put_flags_bor(t_flags *flags, int width, int *cpt)
{
	int	buf;

	buf = width;
	if (width > 0 && !flags->bol_min && !is_incharset("diuxX", flags->c))
	{
		while (width-- > 0)
		{
			if (!flags->bol_0)
				put_char_cpt(cpt, ' ');
			else
				put_char_cpt(cpt, '0');
		}
	}
	else if (is_incharset("diuxX", flags->c) && !flags->bol_min)
	{
		if (flags->width > flags->precision)
			put_width_sup(flags, flags->width - buf, width, cpt);
		else
			put_width_inf(flags, cpt, &width);
	}
}

void	put_width_inf(t_flags *flags, int *cpt, int *width)
{
	if (flags->bol_plu && !flags->signe)
		put_char_cpt(cpt, '+');
	else if (flags->signe == 1)
		put_char_cpt(cpt, '-');
	else if (flags->bol_space)
		put_char_cpt(cpt, ' ');
	while ((*width)-- > 0)
		put_char_cpt(cpt, '0');
}

void	put_width_sup(t_flags *flags, int len_nbr, int width, int *cpt)
{
	int		max;
	char	*hstr;

	hstr = "0x";
	if (flags->c == 'X')
		hstr = "0X";
	if (flags->precision > len_nbr)
		max = flags->precision - len_nbr;
	else
		max = 0;
	if (flags->bol_die)
	{
		if (flags->width - flags->precision != 1)
			width--;
		width--;
	}
	if (flags->bol_plu && !flags->signe)
		width--;
	else if (flags->bol_space && len_nbr > flags->precision && !flags->signe)
		decr_and_put(cpt, ' ', &width);
	while (width - (max) > flags->signe && flags->bol_poi)
		decr_and_put(cpt, ' ', &width);
	put_last_flags(hstr, flags, &width, cpt);
}

void	put_last_flags(char *hstr, t_flags *flags, int *width, int *cpt)
{
	if (flags->bol_0)
	{
		if (flags->bol_die)
			put_str_cpt(cpt, hstr);
		if (flags->bol_plu && !flags->signe)
			put_char_cpt(cpt, '+');
		if (flags->signe)
			put_char_cpt(cpt, '-');
		while ((*width)-- > flags->signe)
			put_char_cpt(cpt, '0');
	}
	else
	{
		while ((*width)-- > flags->signe && !flags->bol_poi)
			put_char_cpt(cpt, ' ');
		if (flags->bol_die)
			put_str_cpt(cpt, hstr);
		if (flags->bol_plu && !flags->signe)
			put_char_cpt(cpt, '+');
		if (flags->signe)
			put_char_cpt(cpt, '-');
		while ((*width)-- >= flags->signe)
			put_char_cpt(cpt, '0');
	}
}

void	put_str_cpt(int *cpt, char *str)
{
	(*cpt) += (int)ft_strlen(str);
	ft_putstr_fd(str, 1);
}
