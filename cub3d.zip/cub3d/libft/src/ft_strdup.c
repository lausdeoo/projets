/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 11:14:18 by tcros             #+#    #+#             */
/*   Updated: 2025/10/13 16:23:40 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s)
{
	char	*dest;
	size_t	len;

	if (!s)
		return (NULL);
	len = ft_strlen(s) + 1;
	dest = malloc((len) * sizeof(char));
	if (dest == NULL)
		return (dest);
	ft_strlcpy(dest, s, len);
	return (dest);
}
