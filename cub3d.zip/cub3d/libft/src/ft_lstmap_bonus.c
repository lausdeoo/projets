/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/18 10:36:52 by tcros             #+#    #+#             */
/*   Updated: 2024/11/18 13:09:47 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	*map;
	void	*tmp;
	t_list	*new;

	if (!lst)
		return (NULL);
	map = NULL;
	while (lst)
	{
		tmp = f(lst->content);
		new = ft_lstnew(tmp);
		if (!new->content)
		{
			del(tmp);
			ft_lstclear(&map, del);
			return (NULL);
		}
		ft_lstadd_back(&map, new);
		lst = lst->next;
	}
	return (map);
}
/*
t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	**map;
	t_list	*tmp;

	map = (t_list **)malloc(sizeof(t_list *));
	if (!lst || !map)
	{
		free(map);
		return (NULL);
	}
	*map = ft_lstnew(f(lst->content));
	if (!(*map))
	{
		free(map);
		return(NULL);
	}
	tmp = *map;
	lst = lst->next;
	while (lst)
	{
		(*map)->next = ft_lstnew(f(lst->content));
		if (!(*map)->next)
		{
			ft_lstclear(&tmp, del);
			free(map);
			return (NULL);
		}
		*map = (*map)->next;
		lst = lst->next;
	}
	return (tmp);
}

#include <stdio.h>

int	main(void)
{
	printf("%lu\n", sizeof(t_list *));
	return (0);
}*/
