/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_format_2.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/05 17:59:14 by tcros             #+#    #+#             */
/*   Updated: 2024/12/17 15:45:09 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	put_format_d(t_flags *flags, int nbr, int *cpt)
{
	int	len_nbr;

	if (nbr == -2147483648)
	{
		if (flags->bol_min)
			put_str_cpt(cpt, "-2147483648");
		else
			put_str_cpt(cpt, "2147483648");
		return ;
	}
	if (flags->signe)
		nbr = -nbr;
	len_nbr = taille_nbr(nbr, 10);
	if (nbr == 0 && !flags->precision)
		len_nbr = 0;
	if (flags->bol_min)
		put_bol_min_nbr(nbr, flags, cpt, len_nbr);
	else
	{
		if (flags->precision == 0 && nbr == 0)
			return ;
		*cpt += len_nbr;
		ft_putnbr_fd(nbr, 1);
	}
}

void	put_format_i(t_flags *flags, int nbr, int *cpt)
{
	int	len_nbr;

	if (nbr == -2147483648)
	{
		if (flags->bol_min)
			put_str_cpt(cpt, "-2147483648");
		else
			put_str_cpt(cpt, "2147483648");
		return ;
	}
	if (flags->signe)
		nbr = -nbr;
	len_nbr = taille_nbr(nbr, 10);
	if (nbr == 0 && !flags->precision)
		len_nbr = 0;
	if (flags->bol_min)
		put_bol_min_nbr(nbr, flags, cpt, len_nbr);
	else
	{
		if (flags->precision == 0 && nbr == 0)
			return ;
		*cpt += len_nbr;
		ft_putnbr_fd(nbr, 1);
	}
}

void	put_format_u(t_flags *flags, unsigned int nbr, int *cpt)
{
	int	len_nbr;

	len_nbr = taille_nbr_un(nbr, 10);
	if (nbr == 0 && !flags->precision)
		len_nbr = 0;
	if (flags->bol_min)
		put_bol_min_nbr(nbr, flags, cpt, len_nbr);
	else
	{
		if (flags->precision == 0 && nbr == 0)
			return ;
		*cpt += len_nbr;
		ft_putnbrun_fd(nbr, 1);
	}
}

void	put_format_x(t_flags *flags, unsigned int nbr, int *cpt)
{
	char	*hexa;
	int		len_nbr;

	hexa = convert_tohex(nbr, "0123456789abcdef");
	len_nbr = (int)ft_strlen(hexa);
	if (nbr == 0 && !flags->precision)
		len_nbr = 0;
	if (flags->bol_min)
		put_bol_min_str(hexa, flags, cpt, len_nbr);
	else
	{
		if (flags->precision == 0 && nbr == 0)
			return ;
		*cpt += len_nbr;
		ft_putstr_fd(hexa, 1);
	}
	free(hexa);
}

void	put_format_xmaj(t_flags *flags, unsigned int nbr, int *cpt)
{
	char	*hexa;
	int		len_nbr;

	hexa = convert_tohex(nbr, "0123456789ABCDEF");
	len_nbr = (int)ft_strlen(hexa);
	if (nbr == 0 && !flags->precision)
		len_nbr = 0;
	if (flags->bol_min)
		put_bol_min_str(hexa, flags, cpt, len_nbr);
	else
	{
		if (flags->precision == 0 && nbr == 0)
			return ;
		*cpt += len_nbr;
		ft_putstr_fd(hexa, 1);
	}
	free(hexa);
}
