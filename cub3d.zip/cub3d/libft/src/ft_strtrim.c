/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 13:45:46 by tcros             #+#    #+#             */
/*   Updated: 2024/11/14 15:32:30 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_is_in_set(char const *set, char c)
{
	int	i;

	i = 0;
	while (set[i])
	{
		if (set[i] == c)
			return (1);
		i++;
	}
	return (0);
}

static size_t	ft_cpt_totrim(char const *s1, char const *set)
{
	size_t	cpt;
	size_t	i;
	size_t	length;

	length = ft_strlen(s1);
	i = 0;
	cpt = 0;
	if (ft_is_in_set(set, s1[0]))
	{
		while (ft_is_in_set(set, s1[i]))
		{
			cpt++;
			i++;
		}
	}
	i = 0;
	if (ft_is_in_set(set, s1[length - 1]) && cpt < length)
	{
		while (ft_is_in_set(set, s1[length - i - 1]))
		{
			cpt++;
			i++;
		}
	}
	return (length - cpt);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	char	*dest;
	size_t	i;
	size_t	l;
	size_t	length_dest;

	length_dest = ft_cpt_totrim(s1, set);
	dest = (char *)malloc((length_dest + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	i = 0;
	while (ft_is_in_set(set, s1[i]))
		i++;
	l = 0;
	while (l < length_dest)
		dest[l++] = s1[i++];
	dest[l] = '\0';
	return (dest);
}
