/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_args_2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/18 11:54:50 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 11:55:07 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

void	put_bol_min_nbr(unsigned long nbr, t_flags *flags, int *cpt, int lnbr)
{
	int	width;

	width = width_for_min(flags, lnbr);
	if (flags->width >= flags->precision)
	{
		test_if_min(flags, lnbr, &width, cpt);
		*cpt += lnbr;
		if (!(nbr == 0 && !flags->precision))
			ft_putnbrun_fd(nbr, 1);
		while (width-- > 0)
			put_char_cpt(cpt, ' ');
	}
	else
	{
		test_else_min(flags, lnbr, &width, cpt);
		*cpt += lnbr;
		ft_putnbrun_fd(nbr, 1);
	}
}

void	put_bol_min_str(char *str, t_flags *flags, int *cpt, int len_nbr)
{
	int		width;

	width = width_for_min(flags, len_nbr);
	if (flags->width > flags->precision)
	{
		test_if_min(flags, len_nbr, &width, cpt);
		*cpt += len_nbr;
		if (!(is_str0(str) && !flags->precision))
			ft_putstr_fd(str, 1);
		while (width-- > 0)
			put_char_cpt(cpt, ' ');
	}
	else
	{
		test_else_min(flags, len_nbr, &width, cpt);
		*cpt += len_nbr;
		ft_putstr_fd(str, 1);
	}
}

void	test_if_min(t_flags *flags, int len_nbr, int *width, int *cpt)
{
	int	i;

	i = flags->precision - len_nbr;
	if (i < 0)
		i = 0;
	if (is_incharset("xX", flags->c))
	{
		if (flags->bol_die)
		{
			(*width) -= 2;
			if (flags->c == 'x')
				put_str_cpt(cpt, "0x");
			else
				put_str_cpt(cpt, "0X");
		}
	}
	if (flags->bol_space && !flags->signe)
		decr_and_put(cpt, ' ', width);
	else if (flags->signe)
		put_char_cpt(cpt, '-');
	else if (flags->bol_plu)
		decr_and_put(cpt, '+', width);
	(*width) -= i;
	while (i > 0 && flags->bol_poi)
		decr_and_put(cpt, '0', &i);
}

void	test_else_min(t_flags *flags, int len_nbr, int *width, int *cpt)
{
	if (flags->bol_space && !flags->signe)
		put_char_cpt(cpt, ' ');
	else if (flags->signe)
		put_char_cpt(cpt, '-');
	else if (flags->bol_plu)
		put_char_cpt(cpt, '+');
	if (len_nbr >= flags->precision)
		(*width)--;
	while ((*width)-- > -flags->signe)
		put_char_cpt(cpt, '0');
}

int	put_s_if_null(t_flags *flags, const char *c, int *cpt)
{
	if (!c && !flags->bol_min)
	{
		if (flags->bol_poi)
		{
			if (flags->precision >= 6)
				put_str_cpt(cpt, "(null)");
		}
		else
			put_str_cpt(cpt, "(null)");
		return (-1000);
	}
	return (width_for_s(c, flags));
}
