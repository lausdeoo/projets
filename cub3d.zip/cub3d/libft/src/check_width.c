/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_width.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/18 14:57:04 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 14:57:04 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_printf.h"

int	width_to_put(t_flags *flags, va_list cpy)
{
	unsigned long int	addr;

	addr = 0;
	if (flags->c == 'c')
		return (flags->width - 1);
	else if (flags->c == 's')
		return (width_for_s(va_arg(cpy, const char *), flags));
	else if (flags->c == 'p')
	{
		addr = va_arg(cpy, unsigned long int);
		if (!addr)
		{
			flags->bol_die = 0;
			return (flags->width - 5);
		}
		if (flags->width > taille_nbr_un(addr, 16))
			return (flags->width - taille_nbr_un(addr, 16) - 2);
		else
			return (0);
	}
	else if (is_incharset("diuxX", flags->c))
		return (all_width_nbr(flags, cpy));
	else
		return (0);
}

int	width_for_nbr(t_flags *flags, int len_nbr)
{
	if (flags->precision >= flags->width && flags->precision > len_nbr)
		return (flags->precision - len_nbr);
	else if (flags->precision < flags->width
		&& flags->width > len_nbr && flags->precision)
		return (flags->width - len_nbr);
	else if (flags->precision == 0)
		return (flags->width - len_nbr);
	else
		return (0);
}

int	width_for_min(t_flags *flags, int len_nbr)
{
	if (flags->precision >= flags->width && flags->precision > len_nbr)
		return (flags->precision - len_nbr - flags->signe);
	else if (flags->precision < flags->width && flags->width > len_nbr)
		return (flags->width - len_nbr - flags->signe);
	else
		return (0);
}

int	all_width_nbr(t_flags *flags, va_list cpy)
{
	unsigned long int	nhex;

	if (is_incharset("xX", flags->c))
	{
		nhex = va_arg(cpy, unsigned int);
		if (!nhex)
			flags->bol_die = 0;
		if (nhex == 0 && !flags->precision)
			return (width_for_nbr(flags, 0));
		return (width_for_nbr(flags, taille_nbr_un(nhex, 16)));
	}
	else if (is_incharset("di", flags->c))
		return (width_for_int(cpy, flags));
	else
	{
		nhex = va_arg(cpy, unsigned int);
		if (nhex == 0 && !flags->precision)
			return (width_for_nbr(flags, 0));
		return (width_for_nbr(flags, taille_nbr_un(nhex, 10)));
	}
}

int	width_for_int(va_list cpy, t_flags *flags)
{
	int	nbr;

	nbr = va_arg(cpy, int);
	if (nbr < 0)
		flags->signe = 1;
	if (nbr == 0 && !flags->precision)
		return (width_for_nbr(flags, 0));
	return (width_for_nbr(flags, taille_nbr(nbr, 10)));
}
