/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_format_1.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/11 16:29:18 by tcros             #+#    #+#             */
/*   Updated: 2024/12/18 13:19:56 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	put_format_s(t_flags *flags, const char *c, int *cpt)
{
	int	i;
	int	nwidth;

	nwidth = put_s_if_null(flags, c, cpt);
	if (!c && nwidth == -1000)
		return ;
	i = 0;
	if (flags->bol_poi && c)
		while (i < flags->precision && c[i])
			put_char_cpt(cpt, c[i++]);
	else if (c)
		put_str_cpt(cpt, (char *)c);
	else if (!flags->bol_poi)
		put_str_cpt(cpt, "(null)");
	else if (flags->bol_poi
		&& flags->precision > flags->width && flags->precision >= 6)
		put_str_cpt(cpt, "(null)");
	else if (flags->bol_poi && flags->width >= 6 && flags->precision >= 6)
		put_str_cpt(cpt, "(null)");
	if (flags->bol_min)
	{
		while (nwidth-- > 0)
			put_char_cpt(cpt, ' ');
	}
}

void	put_format_c(t_flags *flags, char c, int *cpt)
{
	int	i;

	i = flags->width;
	if (flags->bol_min)
	{
		(*cpt)++;
		ft_putchar_fd(c, 1);
		while (i-- > 1)
		{
			(*cpt)++;
			ft_putchar_fd(' ', 1);
		}
	}
	else
	{
		ft_putchar_fd(c, 1);
		(*cpt)++;
	}
}

void	put_format_p(t_flags *flags, unsigned long int addr, int *cpt)
{
	char	*str;
	int		nwidth;
	int		check;

	check = 0;
	if (!addr)
	{
		check = 1;
		str = "(nil)";
	}
	else
		str = convert_tohex(addr, "0123456789abcdef");
	if (flags->width > (int)ft_strlen(str) - 2 && addr)
		nwidth = flags->width - (int)ft_strlen(str) - 2;
	else if (!addr)
		nwidth = flags->width - (int)ft_strlen(str);
	else
		nwidth = 0;
	*cpt += (int)ft_strlen(str);
	ft_putstr_fd(str, 1);
	if (flags->bol_min)
		while (nwidth-- > 0)
			put_char_cpt(cpt, ' ');
	if (!check)
		free(str);
}

void	put_format_perc(int *cpt)
{
	(*cpt)++;
	ft_putchar_fd('%', 1);
}

int	width_for_s(const char *c, t_flags *flags)
{
	int	len_str;

	if (!c)
	{
		if (flags->bol_poi && flags->precision < 6)
			return (flags->width);
		else if (flags->precision >= 6)
			return (flags->width - 6);
		else
			return (flags->width - 6);
	}
	len_str = ft_strlen(c);
	if (flags->width > len_str && !flags->bol_poi)
		return (flags->width - len_str);
	else if (flags->width >= flags->precision
		&& flags->bol_poi && flags->precision < len_str)
		return (flags->width - flags->precision);
	else if (flags->width >= flags->precision
		&& flags->bol_poi && flags->precision >= len_str)
		return (flags->width - len_str);
	else if (flags->precision > flags->width
		&& flags->bol_poi && flags->width > len_str)
		return (flags->width - len_str);
	else
		return (0);
}
