/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/03 15:55:29 by tcros             #+#    #+#             */
/*   Updated: 2025/02/07 14:37:06 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"
#include <string.h>

char	*get_next_line(int fd)
{
	static char	buffer[MAX_FD][BUFFER_SIZE + 1] = {0};
	char		*line;
	int			r_str;

	line = malloc(BUFFER_SIZE + 1);
	if (!line || (BUFFER_SIZE <= 0 || fd < 0 || fd >= MAX_FD))
		return (free(line), NULL);
	erase_buf(line, BUFFER_SIZE);
	if (is_char_in(buffer[fd], '\n'))
		return (line_with_nl(buffer[fd], line));
	ft_strlcpy(line, buffer[fd], BUFFER_SIZE);
	erase_buf(buffer[fd], BUFFER_SIZE);
	r_str = read(fd, buffer[fd], BUFFER_SIZE);
	if (r_str == -1 || (line[0] == '\0' && !r_str))
		return (free(line), NULL);
	while (r_str)
	{
		if (is_char_in(buffer[fd], '\n'))
			return (line_with_nl(buffer[fd], line));
		line = ft_strjoin_for_gnl(line, buffer[fd]);
		erase_buf(buffer[fd], BUFFER_SIZE);
		r_str = read(fd, buffer[fd], BUFFER_SIZE);
	}
	return (line);
}

char	*line_with_nl(char *buffer, char *line)
{
	char	*tmp;
	size_t	offset;

	tmp = buff_bef_nl(buffer, '\n');
	if (!tmp)
		return (free(line), NULL);
	line = ft_strjoin_for_gnl(line, tmp);
	free(tmp);
	tmp = ft_strchr(buffer, '\n');
	offset = tmp - buffer + 1;
	ft_memmove(buffer, buffer + offset, ft_strlen(buffer) - offset + 1);
	return (line);
}

void	erase_buf(char *buffer, int taille)
{
	int	i;

	i = 0;
	while (i < taille + 1)
		buffer[i++] = 0;
}

int	is_char_in(char *str, char c)
{
	int	i;

	i = 0;
	while (str[i])
		if (str[i++] == c)
			return (i);
	return (0);
}

char	*buff_bef_nl(char *str, char stop)
{
	int		i;
	int		size;
	char	*tmp;

	size = is_char_in(str, stop);
	i = 0;
	tmp = malloc(size + 1);
	if (!tmp)
		return (NULL);
	erase_buf(tmp, size);
	while (str[i] != stop && str[i])
	{
		tmp[i] = str[i];
		i++;
	}
	tmp[i] = stop;
	return (tmp);
}
