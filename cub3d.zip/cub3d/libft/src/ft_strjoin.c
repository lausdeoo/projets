/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 13:32:27 by tcros             #+#    #+#             */
/*   Updated: 2024/11/14 13:47:39 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*dest;
	size_t	i;
	size_t	k;
	size_t	tot_length;

	tot_length = ft_strlen(s1) + ft_strlen(s2);
	dest = (char *)malloc((tot_length + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	i = 0;
	while (i < ft_strlen(s1) && s1[i])
	{
		dest[i] = s1[i];
		i++;
	}
	k = 0;
	while (i < tot_length && s2[k])
		dest[i++] = s2[k++];
	dest[i] = '\0';
	return (dest);
}
