/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/13 14:23:16 by tcros             #+#    #+#             */
/*   Updated: 2024/11/14 11:28:09 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	size_t			i;
	unsigned char	*desttmp;
	unsigned char	*srctmp;

	desttmp = ((unsigned char *)dest);
	srctmp = ((unsigned char *)src);
	if (dest == src)
		return (dest);
	if (src > dest)
	{
		i = 0;
		while (i < n)
		{
			desttmp[i] = srctmp[i];
			i++;
		}
	}
	else
	{
		i = n;
		while (i-- > 0)
			desttmp[i] = srctmp[i];
	}
	return (dest);
}
