/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 15:58:04 by tcros             #+#    #+#             */
/*   Updated: 2024/11/18 13:58:43 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	ft_size_nbr(unsigned int n)
{
	size_t	cpt;

	cpt = 0;
	if (n == 0)
		cpt++;
	while (n > 0)
	{
		n = n / 10;
		cpt++;
	}
	return (cpt);
}

static void	ft_converting(char *dest, unsigned int n, size_t i)
{
	if (n == 0)
		dest[0] = 0 + '0';
	else if (n < 10)
		dest[i] = n + '0';
	else
	{
		dest[i] = (n % 10) + '0';
		ft_converting(dest, n / 10, --i);
	}
}

char	*ft_itoa(int n)
{
	char			*dest;
	size_t			length;
	size_t			signe;
	unsigned int	nbr;

	signe = 0;
	if (n < 0)
	{
		signe = 1;
		nbr = -n;
	}
	else
		nbr = n;
	length = ft_size_nbr(nbr);
	dest = (char *)malloc((length + signe + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	if (n < 0)
		dest[0] = '-';
	ft_converting(dest, nbr, length - 1 + signe);
	dest[length + signe] = '\0';
	return (dest);
}
/*
int	main(void)
{
	printf("resultat final = %s\n",ft_itoa(-10004));
	printf("resultat final = %s\n",ft_itoa(0));
	printf("resultat final = %s\n",ft_itoa(1000034));
	printf("resultat final = %s\n",ft_itoa(2147483647));
	printf("resultat final = %s\n",ft_itoa(-2147483648));
}*/
