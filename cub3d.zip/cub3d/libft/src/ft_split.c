/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/14 15:33:56 by tcros             #+#    #+#             */
/*   Updated: 2025/04/02 12:44:10 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	nbr_split(char const *str, char charset)
{
	int	i;
	int	cpt;
	int	check;

	check = 1;
	cpt = 0;
	i = 0;
	while (str[i])
	{
		if (str[i] == charset)
		{
			i++;
			check = 1;
			continue ;
		}
		if (check == 1)
			cpt++;
		i++;
		check = 0;
	}
	return (cpt);
}

static int	set_k(int k, char const *str, char charset)
{
	while (!(str[k] == charset) && str[k])
		k++;
	return (k);
}

static int	set_tot(int cpt, char const *str, char charset)
{
	while (str[cpt] == charset)
		cpt++;
	return (cpt);
}

char	**ft_split(char const *s, char c)
{
	char	**tab;
	int		i;
	int		j;
	int		tot;

	if (!s)
		return (NULL);
	tab = malloc((nbr_split(s, c) + 1) * sizeof(char *));
	if (tab == NULL)
		return (tab);
	i = 0;
	tot = 0;
	while (i < nbr_split(s, c))
	{
		tot = set_tot(tot, s, c);
		tab[i] = malloc(sizeof(char) * (set_k(tot, s, c) - tot + 1));
		if (tab[i] == NULL)
			return (tab);
		j = 0;
		while (!(s[tot] == c) && s[tot])
			tab[i][j++] = s[tot++];
		tab[i++][j] = '\0';
	}
	tab[i] = NULL;
	return (tab);
}
