/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils_bonus.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/03 16:03:07 by tcros             #+#    #+#             */
/*   Updated: 2025/03/27 17:41:11 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

char	*ft_strjoin_for_gnl(char *s1, char const *s2)
{
	char	*dest;
	size_t	i;
	size_t	k;
	size_t	tot_length;
	size_t	size_s1;

	tot_length = ft_strlen(s1) + ft_strlen(s2);
	size_s1 = ft_strlen(s1);
	dest = (char *)malloc((tot_length + 1) * sizeof(char));
	if (!dest)
		return (NULL);
	i = 0;
	while (i < size_s1 && s1[i])
	{
		dest[i] = s1[i];
		i++;
	}
	k = 0;
	while (i < tot_length && s2[k])
		dest[i++] = s2[k++];
	dest[i] = '\0';
	free(s1);
	return (dest);
}
