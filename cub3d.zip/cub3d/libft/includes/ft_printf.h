/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/04 11:50:19 by tcros             #+#    #+#             */
/*   Updated: 2024/12/27 11:58:26 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include "libft.h"

typedef struct s_flags
{
	char	c;
	int		bol_min;
	int		bol_0;
	int		bol_poi;
	int		bol_die;
	int		bol_space;
	int		bol_plu;
	int		width;
	int		precision;
	int		signe;
}	t_flags;

int		ft_printf(const char *str, ...);
void	start_format(const char *str, int *i, va_list ptr, int *cpt);
void	init_flags(t_flags *flags);
void	check_flags(t_flags *flags, const char *str, int i);
void	check_precision(t_flags *flags, const char *str, int *i);
void	recheck_flags(t_flags *flags);
int		is_incharset(const char *cset, char c);
int		is_str0(const char *str);

void	put_all(t_flags *flags, va_list ptr, int *cpt);
void	put_flags(t_flags *flags, va_list cpy, int *cpt);
void	put_flags_bor(t_flags *flags, int width, int *cpt);
void	put_last_flags(char *hstr, t_flags *flags, int *width, int *cpt);
void	put_bol_min_nbr(unsigned long nbr, t_flags *flags, int *cpt, int lnbr);
void	put_bol_min_str(char *str, t_flags *flags, int *cpt, int len_nbr);
void	test_if_min(t_flags *flags, int len_nbr, int *width, int *cpt);
void	test_else_min(t_flags *flags, int len_nbr, int *width, int *cpt);
void	put_char_cpt(int *cpt, char c);
void	put_str_cpt(int *cpt, char *str);
void	put_width_sup(t_flags *flags, int len_nbr, int width, int *cpt);
void	put_width_inf(t_flags *flags, int *cpt, int *width);
void	ft_putnbrun_fd(unsigned long int n, int fd);
void	decr_and_put(int *cpt, char c, int *width);

void	put_format_c(t_flags *flags, char c, int *cpt);
void	put_format_s(t_flags *flags, const char *c, int *cpt);
void	put_format_p(t_flags *flags, unsigned long int addr, int *cpt);
int		put_s_if_null(t_flags *flags, const char *c, int *cpt);
void	put_format_d(t_flags *flags, int nbr, int *cpt);
void	put_format_i(t_flags *flags, int nbr, int *cpt);
void	put_format_u(t_flags *flags, unsigned int nbr, int *cpt);
void	put_format_x(t_flags *flags, unsigned int nbr, int *cpt);
void	put_format_xmaj(t_flags *flags, unsigned int nbr, int *cpt);
void	put_format_perc(int *cpt);

int		width_to_put(t_flags *flags, va_list cpy);
int		width_for_min(t_flags *flags, int len_nbr);
int		width_for_nbr(t_flags *flags, int len_nbr);
int		width_for_s(const char *c, t_flags *flags);
int		width_for_int(va_list cpy, t_flags *flags);
int		width_for_null_s(t_flags *flags);
int		all_width_nbr(t_flags *flags, va_list cpy);
char	*convert_tohex(unsigned long int addr, char *base);
int		taille_nbr(int nbr, int taille_base);
int		taille_nbr_un(unsigned long int nbr, int taille_base);

#endif
