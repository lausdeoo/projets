/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.h                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/03 16:00:58 by tcros             #+#    #+#             */
/*   Updated: 2025/02/07 11:18:29 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_BONUS_H
# define GET_NEXT_LINE_BONUS_H

# include "libft.h"

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 42
# endif

# ifndef MAX_FD
#  define MAX_FD 1024
# endif

char	*get_next_line(int fd);
char	*line_with_nl(char *buffer, char *line);
int		is_char_in(char *str, char c);
char	*buff_bef_nl(char *str, char stop);
void	erase_buf(char *buffer, int taille);

char	*ft_strjoin_for_gnl(char *s1, char const *s2);

#endif
