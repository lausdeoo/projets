/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:48:17 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/07 14:20:59 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i])
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	return (s1[i] - s2[i]);
}

int	handle_image(t_img *imgfail, t_screen *screen)
{
	if (!imgfail->img)
	{
		imgfail->img = mlx_xpm_file_to_image(screen->mlx, PATH_ERROR,
				&imgfail->width, &imgfail->height);
		if (!imgfail->img)
			return (0);
	}
	return (1);
}
