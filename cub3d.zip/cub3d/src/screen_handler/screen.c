/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   screen.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 11:22:26 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 17:37:48 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_anim(t_screen *screen)
{
	screen->anim.anim_state = 0;
	screen->anim.anim_cpt = 0;
}

static int	init_img(t_img *frame, t_screen *screen, t_game *game)
{
	screen->mmap_w = MMAP_W + MMAP_OFFSET;
	screen->mmap_h = MMAP_H + MMAP_OFFSET;
	frame->img = mlx_new_image(screen->mlx, screen->w, screen->h);
	if (!frame->img)
		return (new_error(&game->exit, NEW_IMG_FAIL));
	return (0);
}

static int	init_screen(t_screen *screen, t_img *frame, t_game *game)
{
	ft_strlcpy(game->exit.err, SCREEN_ERR, 200);
	screen->w = WIDTH;
	screen->h = HEIGHT;
	screen->pitch = 0;
	screen->mlx = mlx_init();
	screen->door.doors_map = NULL;
	if (!screen->mlx)
		return (new_error(&game->exit, MLX_INIT_FAIL));
	screen->win = mlx_new_window(screen->mlx, WIDTH, HEIGHT, "cube3d");
	if (!screen->win)
		return (new_error(&game->exit, NEW_WIN_FAIL));
	if (init_img(frame, screen, game))
		return (1);
	screen->frame = *frame;
	if (init_tex(screen, game))
		return (1);
	if (BONUS == 1)
	{
		screen->door.doors_map = copy_map_doors(game->map_info.map);
		if (!screen->door.doors_map)
			return (1);
		init_anim(screen);
	}
	game->screen = *screen;
	return (0);
}

// Func : appelle au raycasting pour determiner l'affichage texture
static int	display_textures(t_screen *screen, t_img *frame, t_game *game)
{
	frame->addr = mlx_get_data_addr(frame->img, &frame->bpp,
			&frame->stride, &frame->endian);
	frame->width = screen->w;
	frame->height = screen->h;
	screen->frame = *frame;
	game->screen = *screen;
	mlx_loop_hook(screen->mlx, (int (*)(void *))render, game);
	return (0);
}

void	launch_screen(t_game *game)
{
	t_screen	screen;
	t_img		img;

	if (init_screen(&screen, &img, game))
		exit_all(game, -1);
	if (BONUS == 1)
		mlx_mouse_move(screen.mlx, screen.win, WIDTH / 2, HEIGHT / 2);
	if (input_handler(game))
		exit_all(game, -1);
	if (display_textures(&screen, &img, game))
		exit_all(game, -1);
	mlx_loop(screen.mlx);
}
