/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_screen.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 14:10:34 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 17:34:07 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	init_tex_anim_scnd(t_screen *screen, t_game *game)
{
	screen->anim.anim_img[2].img = mlx_xpm_file_to_image(screen->mlx,
			ANIM_2, &(screen->anim.anim_img[2].width),
			&(screen->anim.anim_img[2].height));
	if (!handle_image(&screen->anim.anim_img[2], screen))
		return (new_error(&game->exit, ANIM_XPM_FAIL), 1);
	screen->anim.anim_img[2].addr
		= mlx_get_data_addr(screen->anim.anim_img[2].img,
			&screen->anim.anim_img[2].bpp,
			&screen->anim.anim_img[2].stride, &screen->anim.anim_img[2].endian);
	if (!screen->anim.anim_img[2].addr)
		return (1);
	screen->anim.anim_img[3].img = mlx_xpm_file_to_image(screen->mlx,
			ANIM_3, &(screen->anim.anim_img[3].width),
			&(screen->anim.anim_img[3].height));
	if (!handle_image(&screen->anim.anim_img[3], screen))
		return (new_error(&game->exit, ANIM_XPM_FAIL), 1);
	screen->anim.anim_img[3].addr
		= mlx_get_data_addr(screen->anim.anim_img[3].img,
			&screen->anim.anim_img[3].bpp,
			&screen->anim.anim_img[3].stride, &screen->anim.anim_img[3].endian);
	if (!screen->anim.anim_img[3].addr)
		return (1);
	return (0);
}

static int	init_tex_anim(t_screen *screen, t_game *game)
{
	screen->anim.anim_img[0].img = mlx_xpm_file_to_image(screen->mlx,
			ANIM_0, &(screen->anim.anim_img[0].width),
			&(screen->anim.anim_img[0].height));
	if (!handle_image(&screen->anim.anim_img[0], screen))
		return (new_error(&game->exit, ANIM_XPM_FAIL), 1);
	screen->anim.anim_img[0].addr
		= mlx_get_data_addr(screen->anim.anim_img[0].img,
			&screen->anim.anim_img[0].bpp,
			&screen->anim.anim_img[0].stride, &screen->anim.anim_img[0].endian);
	if (!screen->anim.anim_img[0].addr)
		return (1);
	screen->anim.anim_img[1].img = mlx_xpm_file_to_image(screen->mlx,
			ANIM_1, &(screen->anim.anim_img[1].width),
			&(screen->anim.anim_img[1].height));
	if (!handle_image(&screen->anim.anim_img[1], screen))
		return (new_error(&game->exit, ANIM_XPM_FAIL), 1);
	screen->anim.anim_img[1].addr
		= mlx_get_data_addr(screen->anim.anim_img[1].img,
			&screen->anim.anim_img[1].bpp,
			&screen->anim.anim_img[1].stride, &screen->anim.anim_img[1].endian);
	if (!screen->anim.anim_img[1].addr)
		return (1);
	return (init_tex_anim_scnd(screen, game));
}

static int	init_tex_door(t_screen *screen, t_game *game)
{
	if (BONUS == 0)
		return (0);
	screen->door.door_img.img = mlx_xpm_file_to_image(screen->mlx,
			game->map_info.door_asset, &(screen->door.door_img.width),
			&(screen->door.door_img.height));
	if (!handle_image(&screen->door.door_img, screen))
		return (new_error(&game->exit, DOOR_XPM_FAIL), 1);
	screen->door.door_img.addr = mlx_get_data_addr(screen->door.door_img.img,
			&screen->door.door_img.bpp,
			&screen->door.door_img.stride, &screen->door.door_img.endian);
	if (!screen->door.door_img.addr)
		return (1);
	return (init_tex_anim(screen, game));
}

static int	init_tex_scnd(t_screen *screen, t_game *game)
{
	screen->west_img.img = mlx_xpm_file_to_image(screen->mlx,
			game->map_info.west_asset, &screen->west_img.width,
			&screen->west_img.height);
	if (!handle_image(&screen->west_img, screen))
		return (new_error(&game->exit, WEST_XPM_FAIL), 1);
	screen->west_img.addr = mlx_get_data_addr(screen->west_img.img,
			&screen->west_img.bpp,
			&screen->west_img.stride, &screen->west_img.endian);
	if (!screen->west_img.addr)
		return (1);
	screen->east_img.img = mlx_xpm_file_to_image(screen->mlx,
			game->map_info.east_asset, &screen->east_img.width,
			&screen->east_img.height);
	if (!handle_image(&screen->east_img, screen))
		return (new_error(&game->exit, EAST_XPM_FAIL), 1);
	screen->east_img.addr = mlx_get_data_addr(screen->east_img.img,
			&screen->east_img.bpp,
			&screen->east_img.stride, &screen->east_img.endian);
	if (!screen->east_img.addr)
		return (1);
	return (init_tex_door(screen, game));
}

int	init_tex(t_screen *screen, t_game *game)
{
	screen->north_img.img = mlx_xpm_file_to_image(screen->mlx,
			game->map_info.north_asset, &screen->north_img.width,
			&screen->north_img.height);
	if (!handle_image(&screen->north_img, screen))
		return (new_error(&game->exit, NORTH_XPM_FAIL), 1);
	screen->north_img.addr = mlx_get_data_addr(screen->north_img.img,
			&screen->north_img.bpp,
			&screen->north_img.stride, &screen->north_img.endian);
	if (!screen->north_img.addr)
		return (1);
	screen->south_img.img = mlx_xpm_file_to_image(screen->mlx,
			game->map_info.south_asset, &screen->south_img.width,
			&screen->south_img.height);
	if (!handle_image(&screen->south_img, screen))
		return (new_error(&game->exit, SOUTH_XPM_FAIL), 1);
	screen->south_img.addr = mlx_get_data_addr(screen->south_img.img,
			&screen->south_img.bpp,
			&screen->south_img.stride, &screen->south_img.endian);
	if (!screen->south_img.addr)
		return (1);
	return (init_tex_scnd(screen, game));
}
