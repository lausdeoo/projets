/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/04 15:15:13 by tcros             #+#    #+#             */
/*   Updated: 2025/10/07 17:39:57 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

inline void	my_mlx_pixel_put(t_img *frame,
									int x, int y, unsigned int color)
{
	char			*dst;

	if (x < frame->width && y < frame->height && x >= 0 && y >= 0)
	{
		dst = frame->addr + (y * frame->stride + x * (frame->bpp / 8));
		*(unsigned int *)dst = color;
	}
}

static t_img	choose_texture(t_ray ray, t_screen *screen)
{
	if (BONUS == 1 && ray.touched_char == 'D')
		return (screen->door.door_img);
	if (BONUS == 1 && ray.touched_char == 'A')
		return (screen->anim.anim_img[screen->anim.anim_state]);
	if (ray.side == 1)
	{
		if (ray.dir.y > 0)
			return (screen->north_img);
		else
			return (screen->south_img);
	}
	else
	{
		if (ray.dir.x > 0)
			return (screen->east_img);
		else
			return (screen->west_img);
	}
}

void	drawing(int pos, t_ray *ray, t_game *game, int **doors_map)
{
	t_tex	tex;
	double	wall_x;
	int		y;

	tex.texture = choose_texture(*ray, &(game->screen));
	if (ray->side == 0)
		wall_x = game->player.pos.y + ray->perpwalldist * ray->dir.y;
	else
		wall_x = game->player.pos.x + ray->perpwalldist * ray->dir.x;
	wall_x -= floor(wall_x);
	tex.tex_x = (int)(wall_x * (double)tex.texture.width);
	if (BONUS == 1 && doors_map[ray->map_pos.y][ray->map_pos.x] != NOT_A_DOOR)
		tex.tex_x = (int)(fabs(wall_x
					- fabs(((double)doors_map[ray->map_pos.y][ray->map_pos.x])
						/ FRAME_DOOR_OPENING)) * (double)tex.texture.width);
	if ((ray->side == 1 && ray->dir.y > 0)
		|| (ray->side == 0 && ray->dir.x < 0))
		tex.tex_x = tex.texture.width - tex.tex_x - 1;
	tex.line_h = (int)((&(game->screen))->h / ray->perpwalldist);
	y = 0;
	draw_col_h(&y, tex.line_h, &(game->screen), pos);
	draw_col_m(&y, &(game->screen), pos, tex);
	draw_col_l(&y, &(game->screen), pos);
}
