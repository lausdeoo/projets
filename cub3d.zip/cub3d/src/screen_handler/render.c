/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 16:32:08 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 15:54:00 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static t_rgb	init_color(t_color color)
{
	t_rgb	converted;

	converted.t = 0;
	converted.r = color.red;
	converted.g = color.green;
	converted.b = color.blue;
	return (converted);
}

static void	launch_raycasting(t_screen *screen, t_game *game)
{
	t_player	*player;
	t_map		*map;
	t_ray		ray;
	int			x;

	map = &game->map_info;
	player = &game->player;
	x = 0;
	while (x < screen->w)
	{
		ray.camera.x = 2. * x / (double)screen->w - 1.;
		ray.dir.x = player->dir.x + player->plane.x * ray.camera.x;
		ray.dir.y = player->dir.y + player->plane.y * ray.camera.x;
		raycasting(&ray, game);
		screen->floor_color = init_color(map->floor_color);
		screen->ceil_color = init_color(map->ceiling_color);
		drawing(x, &ray, game, game->screen.door.doors_map);
		x++;
	}
	mlx_put_image_to_window(screen->mlx, screen->win, screen->frame.img, 0, 0);
}

static void	anim_update(t_screen *screen)
{
	if (ANIM_RATE < 1)
		return ;
	if (screen->anim.anim_cpt == ANIM_RATE - 1)
	{
		screen->anim.anim_cpt = 0;
		if (screen->anim.anim_state == 3)
			screen->anim.anim_state = 0;
		else
			screen->anim.anim_state++;
	}
	else
		screen->anim.anim_cpt++;
}

int	render(t_game *game)
{
	t_player	*player;
	t_screen	*screen;
	t_map		*map;

	screen = &game->screen;
	player = &game->player;
	map = &game->map_info;
	if (BONUS == 1)
	{
		doors_update(screen, player, map);
		anim_update(screen);
	}
	launch_raycasting(screen, game);
	movement(game, map->map);
	if (BONUS == 1)
		minimap(screen, &screen->frame, game);
	looking(game);
	return (0);
}
