/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/03 16:23:15 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/13 16:12:50 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

void	free_tab_index(void **tab, int i)
{
	if (tab)
	{
		while (i >= 0)
		{
			if (tab[i])
				free(tab[i]);
			i--;
		}
		free(tab);
	}
}

void	free_tab(char **tab)
{
	int	i;

	i = 0;
	if (tab)
	{
		while (tab[i])
		{
			free(tab[i]);
			i++;
		}
		free(tab);
	}
}

void	destroy_sprite_images(t_game *game)
{
	if (game->screen.north_img.img)
		mlx_destroy_image(game->screen.mlx, game->screen.north_img.img);
	if (game->screen.south_img.img)
		mlx_destroy_image(game->screen.mlx, game->screen.south_img.img);
	if (game->screen.west_img.img)
		mlx_destroy_image(game->screen.mlx, game->screen.west_img.img);
	if (game->screen.east_img.img)
		mlx_destroy_image(game->screen.mlx, game->screen.east_img.img);
	if (BONUS == 1)
	{
		if (game->screen.anim.anim_img[0].img)
			mlx_destroy_image(game->screen.mlx,
				game->screen.anim.anim_img[0].img);
		if (game->screen.anim.anim_img[1].img)
			mlx_destroy_image(game->screen.mlx,
				game->screen.anim.anim_img[1].img);
		if (game->screen.anim.anim_img[2].img)
			mlx_destroy_image(game->screen.mlx,
				game->screen.anim.anim_img[2].img);
		if (game->screen.anim.anim_img[3].img)
			mlx_destroy_image(game->screen.mlx,
				game->screen.anim.anim_img[3].img);
	}
}

void	free_map(t_game *game)
{
	if (game->map_info.north_asset)
		free(game->map_info.north_asset);
	if (game->map_info.south_asset)
		free(game->map_info.south_asset);
	if (game->map_info.west_asset)
		free(game->map_info.west_asset);
	if (game->map_info.east_asset)
		free(game->map_info.east_asset);
	if (game->map_info.ceiling_color_str)
		free(game->map_info.ceiling_color_str);
	if (game->map_info.floor_color_str)
		free(game->map_info.floor_color_str);
	if (game->map_info.door_asset)
		free(game->map_info.door_asset);
	if (game->map_info.map)
		free_tab(game->map_info.map);
	if (game->map_info.w)
		free(game->map_info.w);
}

void	free_doors(t_game *game, t_screen screen)
{
	int	i;

	i = 0;
	if (screen.door.doors_map)
	{
		while (screen.door.doors_map[i])
		{
			free(screen.door.doors_map[i]);
			i++;
		}
		free(screen.door.doors_map);
	}
	if (screen.door.door_img.img)
		mlx_destroy_image(game->screen.mlx, screen.door.door_img.img);
}
