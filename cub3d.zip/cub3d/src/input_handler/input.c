/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 11:53:49 by tcros             #+#    #+#             */
/*   Updated: 2025/10/06 11:54:07 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_key_input(t_player *player)
{
	player->w_key = 0;
	player->a_key = 0;
	player->s_key = 0;
	player->d_key = 0;
	player->la_key = 0;
	player->ra_key = 0;
	player->space_key = 0;
}

static void	init_input(t_player *player, t_map map_info)
{
	player->pos.x = (double)map_info.position.x + 0.5;
	player->pos.y = (double)map_info.position.y + 0.5;
	if (is_incharset("NS", map_info.direction))
	{
		player->dir.x = 0.;
		player->dir.y = 1.;
	}
	else if (is_incharset("EW", map_info.direction))
	{
		player->dir.x = 1.;
		player->dir.y = 0.;
	}
	if (is_incharset("NW", map_info.direction))
	{
		player->dir.x = -player->dir.x;
		player->dir.y = -player->dir.y;
	}
	player->plane.x = -player->dir.y * tan(deg_to_rad(FOV) / 2);
	player->plane.y = player->dir.x * tan(deg_to_rad(FOV) / 2);
	player->mov_sp = MOVE_SPEED;
	player->rot_sp = ROTATION_SPEED;
	init_key_input(player);
}

static void	key_press(int keycode, void *arg)
{
	t_player	*player;
	t_game		*game;

	game = (t_game *)arg;
	player = &game->player;
	if (keycode == ESC_KEY)
		exit_all(game, 0);
	if (keycode == W_KEY)
		player->w_key = 1;
	if (keycode == A_KEY)
		player->a_key = 1;
	if (keycode == S_KEY)
		player->s_key = 1;
	if (keycode == D_KEY)
		player->d_key = 1;
	if (keycode == RARROW_KEY)
		player->ra_key = 1;
	if (keycode == LARROW_KEY)
		player->la_key = 1;
	if (keycode == SHIFT_KEY)
		player->mov_sp = 2 * MOVE_SPEED;
	if (keycode == SPACE_KEY)
		player->space_key = 1;
}

static void	key_release(int keycode, void *arg)
{
	t_game		*game;
	t_player	*player;

	game = (t_game *)arg;
	player = &game->player;
	if (keycode == W_KEY)
		player->w_key = 0;
	if (keycode == A_KEY)
		player->a_key = 0;
	if (keycode == S_KEY)
		player->s_key = 0;
	if (keycode == D_KEY)
		player->d_key = 0;
	if (keycode == RARROW_KEY)
		player->ra_key = 0;
	if (keycode == LARROW_KEY)
		player->la_key = 0;
	if (keycode == SHIFT_KEY)
		player->mov_sp = MOVE_SPEED;
	if (keycode == SPACE_KEY)
		player->space_key = 0;
}

int	input_handler(t_game *game)
{
	init_input(&game->player, game->map_info);
	mlx_hook(game->screen.win, 2, 1L << 0, (void *)key_press, game);
	mlx_hook(game->screen.win, 3, 1L << 1, (void *)key_release, game);
	mlx_hook(game->screen.win, 17, 0, exit_all, game);
	return (0);
}
