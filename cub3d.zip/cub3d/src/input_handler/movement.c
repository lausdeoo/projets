/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   movement.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/10 12:12:36 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 10:54:04 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	front_mov(t_player *player, char **map)
{
	t_point	next_pos;

	next_pos.x = (int)(player->pos.x + player->dir.x
			* (player->mov_sp + WDIST));
	next_pos.y = (int)(player->pos.y);
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.x += player->mov_sp * player->dir.x;
	next_pos.x = (int)(player->pos.x);
	next_pos.y = (int)(player->pos.y + player->dir.y
			* (player->mov_sp + WDIST));
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.y += player->mov_sp * player->dir.y;
}

static void	down_mov(t_player *player, char **map)
{
	t_point	next_pos;

	next_pos.x = (int)(player->pos.x - player->dir.x
			* (player->mov_sp + WDIST));
	next_pos.y = (int)(player->pos.y);
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.x -= player->mov_sp * player->dir.x;
	next_pos.x = (int)(player->pos.x);
	next_pos.y = (int)(player->pos.y - player->dir.y
			* (player->mov_sp + WDIST));
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.y -= player->mov_sp * player->dir.y;
}

static void	right_mov(t_player *player, char **map)
{
	t_point	next_pos;

	next_pos.x = (int)(player->pos.x - player->dir.y
			* (player->mov_sp + WDIST));
	next_pos.y = (int)(player->pos.y);
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.x -= player->mov_sp * player->dir.y;
	next_pos.x = (int)(player->pos.x);
	next_pos.y = (int)(player->pos.y + player->dir.x
			* (player->mov_sp + WDIST));
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.y += player->mov_sp * player->dir.x;
}

static void	left_mov(t_player *player, char **map)
{
	t_point	next_pos;

	next_pos.x = (int)(player->pos.x + player->dir.y
			* (player->mov_sp + WDIST));
	next_pos.y = (int)(player->pos.y);
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.x += player->mov_sp * player->dir.y;
	next_pos.x = (int)(player->pos.x);
	next_pos.y = (int)(player->pos.y - player->dir.x
			* (player->mov_sp + WDIST));
	if (is_incharset("0NSEWO", map[next_pos.y][next_pos.x]))
		player->pos.y -= player->mov_sp * player->dir.x;
}

void	movement(t_game *game, char **map)
{
	t_player	*player;

	player = &game->player;
	if (player->w_key)
		front_mov(player, map);
	if (player->s_key)
		down_mov(player, map);
	if (player->d_key)
		right_mov(player, map);
	if (player->a_key)
		left_mov(player, map);
}
