/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   looking.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/10 13:59:05 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 14:57:06 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	right_look(t_player *player)
{
	double	old_dir_x;
	double	old_plane_x;

	old_dir_x = player->dir.x;
	player->dir.x = player->dir.x * cos(player->rot_sp)
		- player->dir.y * sin(player->rot_sp);
	player->dir.y = old_dir_x * sin(player->rot_sp)
		+ player->dir.y * cos(player->rot_sp);
	old_plane_x = player->plane.x;
	player->plane.x = player->plane.x * cos(player->rot_sp)
		- player->plane.y * sin(player->rot_sp);
	player->plane.y = old_plane_x * sin(player->rot_sp)
		+ player->plane.y * cos(player->rot_sp);
}

static void	left_look(t_player *player)
{
	double	old_dir_x;
	double	old_plane_x;

	old_dir_x = player->dir.x;
	player->dir.x = player->dir.x * cos(-player->rot_sp)
		- player->dir.y * sin(-player->rot_sp);
	player->dir.y = old_dir_x * sin(-player->rot_sp)
		+ player->dir.y * cos(-player->rot_sp);
	old_plane_x = player->plane.x;
	player->plane.x = player->plane.x * cos(-player->rot_sp)
		- player->plane.y * sin(-player->rot_sp);
	player->plane.y = old_plane_x * sin(-player->rot_sp)
		+ player->plane.y * cos(-player->rot_sp);
}

static void	mouse_look(t_player *player, t_screen *screen, int x, int y)
{
	double	dy;
	double	dx;

	dy = (y - HEIGHT / 2) / 4;
	dx = (x - WIDTH / 2) / 4;
	if (dy < 0)
		screen->pitch += PITCH * fabs(dy);
	if (dy > 0)
		screen->pitch -= PITCH * fabs(dy);
	if (dx != 0)
		player->rot_sp *= fabs(dx);
	else
		player->rot_sp = ROTATION_SPEED;
	if (player->rot_sp > MAX_ROT)
		player->rot_sp = MAX_ROT;
	if (dx > 0)
		right_look(player);
	if (dx < 0)
		left_look(player);
	if (screen->pitch > HEIGHT)
		screen->pitch = HEIGHT;
	if (screen->pitch < -HEIGHT)
		screen->pitch = -HEIGHT;
}

void	looking(t_game *game)
{
	t_player	*player;
	t_screen	*screen;
	int			x;
	int			y;

	player = &game->player;
	screen = &game->screen;
	if (BONUS == 1)
		mlx_mouse_get_pos(screen->mlx, screen->win, &x, &y);
	if (player->ra_key)
		right_look(player);
	if (player->la_key)
		left_look(player);
	if (BONUS == 1)
	{
		mouse_look(player, screen, x, y);
		mlx_mouse_move(screen->mlx, screen->win, WIDTH / 2, HEIGHT / 2);
	}
}
