/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   doors.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 11:21:05 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/07 17:56:12 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	verif_proxi_door(t_screen *screen, t_player *player)
{
	int	i;
	int	j;
	int	pos_x;
	int	pos_y;
	int	**doors_map;

	doors_map = screen->door.doors_map;
	pos_x = (int)player->pos.x;
	pos_y = (int)player->pos.y;
	i = -1;
	while (i <= 1)
	{
		j = -1;
		while (j <= 1)
		{
			if ((screen->door.doors_map[pos_y + j][pos_x + i] == DOOR_CLOSED
				|| screen->door.doors_map[pos_y + j][pos_x + i] == DOOR_OPEN)
				&& ((j == 0 && (i == 1 || i == -1))
				|| (i == 0 && (j == 1 || j == -1))))
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

static void	transfo_map_doors(int **doors_map, t_map *map,
		t_player *player, int i)
{
	int	j;

	j = -1;
	while (j <= 1)
	{
		if (doors_map[(int)player->pos.y + j][(int)player->pos.x + i]
			== DOOR_CLOSED
			&& ((j == 0 && (i == 1 || i == -1))
			|| (i == 0 && (j == 1 || j == -1))))
			doors_map[(int)player->pos.y + j][(int)player->pos.x + i]
				= DOOR_CLOSED + 1;
		else
		{
			if (doors_map[(int)player->pos.y + j][(int)player->pos.x + i]
				== DOOR_OPEN
				&& ((j == 0 && (i == 1 || i == -1))
				|| (i == 0 && (j == 1 || j == -1))))
			{
				doors_map[(int)player->pos.y + j][(int)player->pos.x + i]
					= DOOR_OPEN * (-1) + 1;
				map->map[(int)player->pos.y + j][(int)player->pos.x + i] = 'D';
			}
		}
		j++;
	}
}

static int	update_proxi_door(t_screen *screen, t_player *player, t_map *map)
{
	int	i;
	int	**doors_map;

	doors_map = screen->door.doors_map;
	i = -1;
	while (i <= 1)
	{
		transfo_map_doors(doors_map, map, player, i);
		i++;
	}
	return (0);
}

static void	update_all_doors(int **doors_map, t_map *map)
{
	int	i;
	int	j;

	j = 0;
	while (doors_map[j])
	{
		i = 0;
		while (doors_map[j][i] != NOT_A_DOOR - 1)
		{
			if (doors_map[j][i] != NOT_A_DOOR
				&& doors_map[j][i] != DOOR_CLOSED
				&& doors_map[j][i] != DOOR_OPEN)
				doors_map[j][i]++;
			else
				if (doors_map[j][i] == DOOR_OPEN)
					map->map[j][i] = 'O';
			i++;
		}
		j++;
	}
}

void	doors_update(t_screen *screen, t_player *player, t_map *map)
{
	update_all_doors(screen->door.doors_map, map);
	if (player->space_key && verif_proxi_door(screen, player))
		update_proxi_door(screen, player, map);
}
