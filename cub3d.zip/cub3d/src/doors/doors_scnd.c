/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   doors_scnd.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/06 11:44:10 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/06 16:38:46 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	set_map_doors(char **map, int **doors_map, int i)
{
	int	j;

	j = 0;
	while (map[i][j])
	{
		if (map[i][j] == 'D')
			doors_map[i][j] = DOOR_CLOSED;
		else
			doors_map[i][j] = NOT_A_DOOR;
		j++;
	}
	doors_map[i][j] = NOT_A_DOOR - 1;
}

int	**copy_map_doors(char **map)
{
	int	i;
	int	len;
	int	**doors_map;

	len = 0;
	while (map[len])
		len++;
	doors_map = malloc(sizeof(int *) * (len + 1));
	if (!doors_map)
		return (NULL);
	i = 0;
	while (map[i])
	{
		len = ft_strlen(map[i]);
		doors_map[i] = malloc(sizeof(int) * (len + 1));
		if (!doors_map)
			return (free_tab_index((void **)doors_map, i), NULL);
		set_map_doors(map, doors_map, i);
		i++;
	}
	doors_map[i] = NULL;
	return (doors_map);
}
