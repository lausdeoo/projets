/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calculations.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/04 13:10:38 by tcros             #+#    #+#             */
/*   Updated: 2025/10/07 17:38:52 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

inline unsigned int	rgb_to_int(t_rgb color)
{
	return (((color.t & 0xFF) << 24) | ((color.r & 0xFF) << 16)
		| ((color.g & 0xFF) << 8) | (color.b & 0xFF));
}

void	left_side_dist(t_ray *ray, double pos, char c)
{
	if (c == 'X')
	{
		ray->step.x = -1;
		ray->side_dist.x = (pos - ray->map_pos.x) * ray->delta_dist.x;
	}
	else if (c == 'Y')
	{
		ray->step.y = -1;
		ray->side_dist.y = (pos - ray->map_pos.y) * ray->delta_dist.y;
	}
}

void	right_side_dist(t_ray *ray, double pos, char c)
{
	if (c == 'X')
	{
		ray->step.x = 1;
		ray->side_dist.x = (ray->map_pos.x + 1.0 - pos) * ray->delta_dist.x;
	}
	else if (c == 'Y')
	{
		ray->step.y = 1;
		ray->side_dist.y = (ray->map_pos.y + 1.0 - pos) * ray->delta_dist.y;
	}
}

double	deg_to_rad(double deg)
{
	return (deg * M_PI / 180.);
}
