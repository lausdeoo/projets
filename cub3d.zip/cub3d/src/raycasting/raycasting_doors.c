/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting_doors.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/06 14:56:18 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/07 17:04:20 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	side_zero_case(t_ray *ray, int **doors_map, t_player *player)
{
	double	wall_x;

	wall_x = player->pos.y + ray->dir.y
		* (ray->side_dist.x - ray->delta_dist.x / 2);
	wall_x -= floor(wall_x);
	if ((ray->side_dist.x - ray->delta_dist.x)
		+ ray->delta_dist.x / 2 < ray->side_dist.y
		&& wall_x > fabs(((double)doors_map[ray->map_pos.y][ray->map_pos.x])
		/ (double)FRAME_DOOR_OPENING))
	{
		ray->side_dist.x += ray->delta_dist.x / 2;
		ray->side = 0;
	}
	else
	{
		ray->side_dist.y += ray->delta_dist.y;
		ray->map_pos.y += ray->step.y;
		ray->side = 1;
	}
}

static void	side_one_case(t_ray *ray, int **doors_map, t_player *player)
{
	double	wall_x;

	wall_x = player->pos.x + ray->dir.x
		* (ray->side_dist.y - ray->delta_dist.y / 2);
	wall_x -= floor(wall_x);
	if (ray->side_dist.x < (ray->side_dist.y - ray->delta_dist.y)
		+ ray->delta_dist.y / 2
		|| wall_x < fabs(((double)doors_map[ray->map_pos.y][ray->map_pos.x])
		/ (double)FRAME_DOOR_OPENING))
	{
		ray->side_dist.x += ray->delta_dist.x;
		ray->map_pos.x += ray->step.x;
		ray->side = 0;
	}
	else
	{
		ray->side_dist.y += ray->delta_dist.y / 2;
		ray->side = 1;
	}
}

void	door_calculation(t_ray *ray, char **map, int *hit, t_game *game)
{
	if (ray->side == 0)
		side_zero_case(ray, game->screen.door.doors_map, &game->player);
	else
		side_one_case(ray, game->screen.door.doors_map, &game->player);
	ray->touched_char = map[ray->map_pos.y][ray->map_pos.x];
	(*hit) = 1;
}
