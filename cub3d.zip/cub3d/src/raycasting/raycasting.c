/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/03 15:50:00 by tcros             #+#    #+#             */
/*   Updated: 2025/10/07 17:19:34 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	dda_init(t_ray *ray, t_player *player)
{
	ray->map_pos.x = (int)player->pos.x;
	ray->map_pos.y = (int)player->pos.y;
	if (ray->dir.x == 0)
		ray->delta_dist.x = INFINITY;
	else
		ray->delta_dist.x = fabs(1 / ray->dir.x);
	if (ray->dir.y == 0)
		ray->delta_dist.y = INFINITY;
	else
		ray->delta_dist.y = fabs(1 / ray->dir.y);
	if (ray->dir.x < 0)
		left_side_dist(ray, player->pos.x, 'X');
	else
		right_side_dist(ray, player->pos.x, 'X');
	if (ray->dir.y < 0)
		left_side_dist(ray, player->pos.y, 'Y');
	else
		right_side_dist(ray, player->pos.y, 'Y');
}

static void	update_ray(t_ray *ray, t_game *game, double *wall_x)
{
	if (ray->side_dist.x < ray->side_dist.y)
	{
		ray->side_dist.x += ray->delta_dist.x;
		ray->map_pos.x += ray->step.x;
		ray->side = 0;
		*wall_x = game->player.pos.y + ray->dir.y
			* (ray->side_dist.x - ray->delta_dist.x / 2);
	}
	else
	{
		ray->side_dist.y += ray->delta_dist.y;
		ray->map_pos.y += ray->step.y;
		ray->side = 1;
		*wall_x = game->player.pos.x + ray->dir.x
			* (ray->side_dist.y - ray->delta_dist.y / 2);
	}
}

static void	dda_loop(t_ray *ray, char **map, t_game *game, int **doors_map)
{
	int		hit;
	double	wall_x;

	hit = 0;
	while (hit == 0)
	{
		update_ray(ray, game, &wall_x);
		wall_x -= floor(wall_x);
		if (!is_incharset("0NSEWOD", map[ray->map_pos.y][ray->map_pos.x]))
		{
			ray->touched_char = map[ray->map_pos.y][ray->map_pos.x];
			hit = 1;
		}
		else if (map[ray->map_pos.y][ray->map_pos.x] == 'D'
			&& wall_x
			> fabs(((double)doors_map[ray->map_pos.y][ray->map_pos.x])
			/ (double)FRAME_DOOR_OPENING))
			door_calculation(ray, map, &hit, game);
	}
}

void	raycasting(t_ray *ray, t_game *game)
{
	dda_init(ray, &game->player);
	dda_loop(ray, game->map_info.map, game, game->screen.door.doors_map);
	if (ray->side == 0)
		ray->perpwalldist = (ray->side_dist.x - ray->delta_dist.x);
	else
		ray->perpwalldist = (ray->side_dist.y - ray->delta_dist.y);
}
