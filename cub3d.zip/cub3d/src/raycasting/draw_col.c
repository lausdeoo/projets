/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_col.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/06 14:30:20 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/07 17:55:27 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

void	draw_col_h(int *y, int line_h, t_screen *screen, int pos)
{
	int	draw_start;

	draw_start = (-line_h) / 2 + screen->h / 2 + screen->pitch;
	if (draw_start < 0)
		draw_start = 0;
	while ((*y) < draw_start)
		my_mlx_pixel_put(&screen->frame,
			pos, (*y)++, rgb_to_int(screen->ceil_color));
}

void	draw_col_m(int *y, t_screen *screen, int pos, t_tex tex)
{
	int				wall_y;
	int				draw_end;
	unsigned int	color;

	draw_end = tex.line_h / 2 + screen->h / 2 + screen->pitch;
	if (draw_end > screen->h)
		draw_end = screen->h;
	while ((*y) < draw_end)
	{
		wall_y = (*y) - screen->h / 2 + tex.line_h / 2 - screen->pitch;
		tex.tex_y = ((wall_y * tex.texture.height) / tex.line_h);
		color = *(unsigned int *)(tex.texture.addr
				+ (tex.tex_y * tex.texture.stride
					+ tex.tex_x * (tex.texture.bpp / 8)));
		my_mlx_pixel_put(&screen->frame, pos, (*y)++, color);
	}
}

void	draw_col_l(int *y, t_screen *screen, int pos)
{
	while ((*y) < screen->h)
		my_mlx_pixel_put(&screen->frame,
			pos, (*y)++, rgb_to_int(screen->floor_color));
}
