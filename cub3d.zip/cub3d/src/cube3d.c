/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cube3d.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 11:58:45 by tcros             #+#    #+#             */
/*   Updated: 2025/10/13 16:36:01 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_screen_img(t_screen *screen)
{
	int	i;

	i = 0;
	while (i < 4)
	{
		screen->anim.anim_img[i].img = NULL;
		i++;
	}
	screen->north_img.img = NULL;
	screen->south_img.img = NULL;
	screen->west_img.img = NULL;
	screen->east_img.img = NULL;
	screen->door.door_img.img = NULL;
}

static void	init_all(t_game *game)
{
	game->exit.out = 0;
	ft_strlcpy(game->exit.err, "", 200);
	ft_strlcpy(game->exit.sub_err, "", 200);
	game->screen.mlx = NULL;
	game->screen.win = NULL;
	game->screen.frame.img = NULL;
	game->map_info.north_asset = NULL;
	game->map_info.south_asset = NULL;
	game->map_info.west_asset = NULL;
	game->map_info.east_asset = NULL;
	game->map_info.ceiling_color_str = NULL;
	game->map_info.floor_color_str = NULL;
	game->map_info.door_asset = NULL;
	game->map_info.direction = '\0';
	game->map_info.map = NULL;
	game->map_info.w = NULL;
	game->map_info.h = 0;
	game->screen.door.doors_map = NULL;
	init_screen_img(&game->screen);
}

int	exit_all(t_game *game, int exit_out)
{
	t_screen	*screen;
	t_img		*frame;

	screen = &game->screen;
	frame = &screen->frame;
	if (exit_out != -1)
		game->exit.out = exit_out;
	if (frame->img)
		mlx_destroy_image(screen->mlx, frame->img);
	destroy_sprite_images(game);
	if (BONUS == 1)
		free_doors(game, game->screen);
	if (screen->win)
		mlx_destroy_window(screen->mlx, screen->win);
	if (screen->mlx)
	{
		mlx_destroy_display(screen->mlx);
		free(screen->mlx);
	}
	if (game->exit.out >= 1)
		error_output(game->exit);
	free_map(game);
	exit(game->exit.out);
	return (game->exit.out);
}

static void	map_size(t_map *map_i)
{
	char	**map;
	int		*w;
	int		h;
	int		i;

	h = 0;
	map = map_i->map;
	while (map[h])
		h++;
	w = malloc(sizeof(int) * (h));
	i = 0;
	while (i < h)
	{
		w[i] = ft_strlen(map[i]);
		i++;
	}
	map_i->h = h - 1;
	map_i->w = w;
}

int	cube3d(int ac, char *av[])
{
	t_game	game;

	init_all(&game);
	check_for_error(ac, av, &game);
	map_size(&game.map_info);
	launch_screen(&game);
	exit_all(&game, -1);
	return (0);
}
