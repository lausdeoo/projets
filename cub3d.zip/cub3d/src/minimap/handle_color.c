/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handle_color.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/19 15:33:53 by tcros             #+#    #+#             */
/*   Updated: 2025/09/19 17:56:28 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static unsigned int	my_pixel_get(t_img *img, int x, int y)
{
	char			*dst;
	unsigned int	color;

	dst = NULL;
	if (x < 0 || y < 0 || x >= img->width || y >= img->height)
		return (0);
	dst = img->addr + (y * img->stride) + x * (img->bpp / 8);
	color = *(unsigned int *)dst;
	return (color);
}

static unsigned int	blend_pixel(unsigned int bg, unsigned int color)
{
	t_rgb			blended;
	double			alpha;

	alpha = (double)((color >> 24) & 0xFF) / 255;
	if (alpha == 1)
		return (color);
	else if (alpha == 0)
		return (bg);
	blended.r = ((((color >> 16) & 0xFF) + ((bg >> 16) & 0xFF)) / 2) * alpha;
	blended.g = ((((color >> 8) & 0xFF) + ((bg >> 8) & 0xFF)) / 2) * alpha;
	blended.b = ((((color) & 0xFF) + ((bg) & 0xFF)) / 2) * alpha;
	return (rgb_to_int(blended));
}

inline void	my_mlx_pixel_put_alpha(t_img *img, int x, int y, unsigned int color)
{
	unsigned int	bg_color;
	unsigned int	blend_color;

	bg_color = my_pixel_get(img, x, y);
	blend_color = blend_pixel(bg_color, color);
	my_mlx_pixel_put(img, x, y, blend_color);
}
