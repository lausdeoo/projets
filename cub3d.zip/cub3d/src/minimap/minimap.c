/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minimap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 13:09:21 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 16:57:51 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	is_incircle(int x, int y, int c)
{
	int	r;

	r = MMAP_W / 2;
	return ((x - c) * (x - c) + (y - c) * (y - c) + OUTLINE < r * r);
}

static void	draw_all(t_screen *screen, t_player *player, t_map *map, int c)
{
	t_point	pos;

	pos.x = MMAP_OFFSET;
	while (pos.x < screen->mmap_w)
	{
		pos.y = MMAP_OFFSET;
		while (pos.y < screen->mmap_h)
		{
			if (is_incircle(pos.x, pos.y, c))
			{
				draw_walls(player, screen, pos, map);
				draw_player(player, screen, pos);
				draw_minimap(screen, pos, c);
			}
			pos.y++;
		}
		pos.x++;
	}
}

void	minimap(t_screen *screen, t_img *minimap, t_game *game)
{
	t_player	*player;
	t_map		*map;
	int			center;

	map = &game->map_info;
	player = &game->player;
	center = (screen->mmap_w + MMAP_OFFSET) / 2;
	draw_all(screen, player, map, center);
	mlx_put_image_to_window(screen->mlx, screen->win, minimap->img, 0, 0);
}
