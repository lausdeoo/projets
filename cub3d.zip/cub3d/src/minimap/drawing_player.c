/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing_player.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/24 11:32:26 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 16:39:13 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_player_color(t_rgb *color)
{
	color->t = PLAY_T;
	color->r = PLAY_R;
	color->g = PLAY_G;
	color->b = PLAY_B;
}

static void	init_pos(t_vector *a, t_vector *b, t_vector *c, const t_vector dir)
{
	int	rayon;
	int	m;
	int	h;

	rayon = ((MMAP_W) / 2) + MMAP_OFFSET;
	h = CUR_HEIGHT;
	m = LITTLE_M;
	a->x = CUR_LENGTH * dir.x + rayon;
	a->y = CUR_LENGTH * dir.y + rayon;
	b->x = m * dir.x - h * dir.y + rayon;
	b->y = m * dir.y + h * dir.x + rayon;
	c->x = m * dir.x + h * dir.y + rayon;
	c->y = m * dir.y - h * dir.x + rayon;
}

static int	is_intriangle(const t_vector dir, int x, int y, double det_ca)
{
	t_vector	a;
	t_vector	b;
	t_vector	c;
	double		det_ab;
	double		det_bc;

	init_pos(&a, &b, &c, dir);
	det_ab = (b.x - a.x) * (y - a.y) - (x - a.x) * (b.y - a.y);
	det_bc = (c.x - b.x) * (y - b.y) - (x - b.x) * (c.y - b.y);
	det_ca = (a.x - c.x) * (y - c.y) - (x - c.x) * (a.y - c.y);
	if ((det_ab > 0 && det_bc > 0 && det_ca > 0)
		|| (det_ab < 0 && det_bc < 0 && det_ca < 0))
		return (1);
	return (0);
}

static void	draw_cursor(t_screen *screen, t_player *player, t_point pos)
{
	t_vector	dir;

	dir = player->dir;
	if (is_intriangle(dir, pos.x, pos.y, 0))
		my_mlx_pixel_put_alpha(&screen->frame, pos.x,
			pos.y, rgb_to_int(player->color));
}

void	draw_player(t_player *player, t_screen *screen, t_point pos)
{
	init_player_color(&player->color);
	draw_cursor(screen, player, pos);
}
