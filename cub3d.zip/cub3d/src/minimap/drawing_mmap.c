/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing_mmap.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 15:04:17 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 16:54:04 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_mmap_color(t_rgb *acolor, t_rgb *bcolor)
{
	acolor->t = MMAP_T;
	acolor->r = MMAP_R;
	acolor->g = MMAP_G;
	acolor->b = MMAP_B;
	bcolor->t = OUT_T;
	bcolor->r = OUT_R;
	bcolor->g = OUT_G;
	bcolor->b = OUT_B;
}

static void	draw_circle(t_screen *screen, t_point pos, t_rgb color)
{
	my_mlx_pixel_put_alpha(&screen->frame, pos.x, pos.y, rgb_to_int(color));
}

static void	draw_outline(t_screen *screen, t_point pos, int c, t_rgb color)
{
	int	rayon;
	int	outline;

	rayon = (screen->mmap_w - MMAP_OFFSET) / 2;
	outline = (pos.x - c) * (pos.x - c) + (pos.y - c) * (pos.y - c) + OUTLINE;
	if (outline + OUTLINE > (rayon * rayon))
		my_mlx_pixel_put_alpha(&screen->frame, pos.x, pos.y, rgb_to_int(color));
}

void	draw_minimap(t_screen *screen, t_point pos, int center)
{
	t_rgb	mmap_color;
	t_rgb	out_color;

	init_mmap_color(&mmap_color, &out_color);
	draw_circle(screen, pos, mmap_color);
	draw_outline(screen, pos, center, out_color);
}
