/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing_walls.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/01 10:27:42 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 17:01:04 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static void	init_wall_color(t_rgb color[])
{
	color[0].t = WALL_T;
	color[1].t = WALL_T;
	color[2].t = WALL_T;
	color[0].r = WALL_R;
	color[0].g = WALL_G;
	color[0].b = WALL_B;
	color[1].r = DOORC_R;
	color[1].g = DOORC_G;
	color[1].b = DOORC_B;
	color[2].r = DOORO_R;
	color[2].g = DOORO_G;
	color[2].b = DOORO_B;
}

static int	is_inwall(t_vector pos, int x, int y, t_map *map_i)
{
	double	map_x;
	double	map_y;
	char	**map;
	int		center;

	center = MMAP_W / 2 + MMAP_OFFSET;
	map_x = pos.x + ((double)(x - center) / CASE_SIZE);
	map_y = pos.y + ((double)(y - center) / CASE_SIZE);
	map = map_i->map;
	if (map_y < 0 || map_x < 0 || map_y > map_i->h
		|| map_x > map_i->w[(int)map_y])
		return (1);
	if (map[(int)map_y][(int)map_x] == ' ')
		return (1);
	if (map[(int)map_y][(int)map_x] == '1')
		return (1);
	if (map[(int)map_y][(int)map_x] == 'A')
		return (1);
	if (map[(int)map_y][(int)map_x] == 'D')
		return (2);
	if (map[(int)map_y][(int)map_x] == 'O')
		return (3);
	return (0);
}

void	draw_walls( t_player *player, t_screen *screen, t_point pos, t_map *map)
{
	t_rgb	color[3];
	int		iswall;

	init_wall_color(color);
	iswall = is_inwall(player->pos, pos.x, pos.y, map);
	if (iswall)
		my_mlx_pixel_put_alpha(&screen->frame, pos.x,
			pos.y, rgb_to_int(color[iswall - 1]));
}
