/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   extension.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:49:26 by nbacconn          #+#    #+#             */
/*   Updated: 2025/09/03 16:16:25 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

int	extension_verif(char *av[], t_error *exit)
{
	int	i;

	i = 0;
	while (av[1][i])
		i++;
	if (i < 4)
		return (new_error(exit, BAD_FORMAT), 1);
	if (av[1][i - 1] != 'b' || av[1][i - 2] != 'u'
		|| av[1][i - 3] != 'c' || av[1][i - 4] != '.')
		return (new_error(exit, BAD_FORMAT), 1);
	return (0);
}
