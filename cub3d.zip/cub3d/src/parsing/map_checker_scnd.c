/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_checker_scnd.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/04 15:35:57 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/06 12:02:24 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

int	get_to_map_index(char **file_tab, int *i, t_game *game)
{
	char	**tmp_tab;

	if (!file_tab[*i])
		return (new_error(&game->exit, NO_MAP), 1);
	tmp_tab = ft_split_whitespaces(file_tab[*i]);
	if (!tmp_tab)
		return (1);
	while (tmp_tab[0] == NULL)
	{
		(*i)++;
		free_tab(tmp_tab);
		if (!file_tab[*i])
			return (new_error(&game->exit, NO_MAP), 1);
		tmp_tab = ft_split_whitespaces(file_tab[*i]);
		if (!tmp_tab)
			return (1);
	}
	free_tab(tmp_tab);
	return (0);
}

char	**create_new_tab_map(char **file_tab, int *i, int nb_lines)
{
	char	**new_tab;
	int		j;

	new_tab = malloc((nb_lines - (*i) + 1) * sizeof(char *));
	if (!new_tab)
		return (NULL);
	new_tab[nb_lines - (*i)] = NULL;
	j = 0;
	while (file_tab[*i])
	{
		new_tab[j] = ft_strdup(file_tab[*i]);
		if (!new_tab[j])
			return (free_tab_index((void **)new_tab, j)
				, NULL);
		(*i)++;
		j++;
	}
	free_tab(file_tab);
	return (new_tab);
}

int	ft_strfind_charset_ws(char *str, char *charset)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
	{
		j = 0;
		while (charset[j])
		{
			if (str[i] == charset[j] || !ft_isprint(str[i])
				|| (BONUS == 1 && (str[i] == 'D' || str[i] == 'A')))
				break ;
			j++;
		}
		if (str[i] == charset[j] || !ft_isprint(str[i])
			|| (BONUS == 1 && (str[i] == 'D' || str[i] == 'A')))
			i++;
		else
			return (1);
	}
	return (0);
}

int	check_wrong_char(char **file_tab, char *charset, t_game *game)
{
	int	i;

	i = 0;
	while (file_tab[i])
	{
		if (ft_strfind_charset_ws(file_tab[i], charset))
			return (new_error(&game->exit, WRONG_CHAR_MAP), 1);
		i++;
	}
	return (0);
}
