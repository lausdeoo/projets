/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 10:26:50 by nbacconn          #+#    #+#             */
/*   Updated: 2025/09/19 09:51:06 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	nb_words(char *string)
{
	int	i;
	int	cpt;
	int	switch_btn;

	i = 0;
	cpt = 0;
	switch_btn = 1;
	while (string[i])
	{
		if (!ft_isprint(string[i]) || string[i] == ' ')
			switch_btn = 1;
		if (ft_isprint(string[i]) && string[i] != ' ' && switch_btn == 1)
		{
			cpt++;
			switch_btn = 0;
		}
		i++;
	}
	return (cpt);
}

static int	len_word(char *string)
{
	int	i;

	i = 0;
	while (ft_isprint(string[i]) && string[i] != ' ')
		i++;
	return (i);
}

static int	split_algo(char *string, char ***tab, int i, int j)
{
	int	cpt;
	int	switch_btn;

	cpt = 0;
	switch_btn = 1;
	while (string[i])
	{
		if (!ft_isprint(string[i]) || string[i] == ' ')
			switch_btn = 1;
		if (ft_isprint(string[i]) && string[i] != ' ' && switch_btn == 0)
			(*tab)[cpt - 1][j++] = string[i];
		if (ft_isprint(string[i]) && string[i] != ' ' && switch_btn == 1)
		{
			(*tab)[cpt] = malloc(sizeof(char) * (len_word(&string[i]) + 1));
			if (!((*tab)[cpt]))
				return (free_tab_index((void **)*tab, cpt), 1);
			j = 0;
			(*tab)[cpt][j++] = string[i];
			(*tab)[cpt][len_word(&string[i])] = '\0';
			cpt++;
			switch_btn = 0;
		}
		i++;
	}
	return (0);
}

char	**ft_split_whitespaces(char *string)
{
	char	**tab;

	tab = malloc((nb_words(string) + 1) * sizeof(char *));
	if (!tab)
		return (free(string), NULL);
	tab[(nb_words(string))] = NULL;
	if (split_algo(string, &tab, 0, 0))
		return (free(string), NULL);
	return (tab);
}
