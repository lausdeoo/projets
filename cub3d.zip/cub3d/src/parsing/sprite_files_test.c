/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sprite_files_test.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/03 11:27:32 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/17 10:49:14 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	testing_file(char *file, char *err, t_error *exit, int *out)
{
	int		fd;

	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		new_error(exit, err);
		(*out)++;
		return (1);
	}
	close(fd);
	return (0);
}

static int	access_anim_sprite(t_error exit, int out)
{
	if (testing_file(ANIM_0, SPRITE_ACCESS_ERR_ANIM, &exit, &out))
		error_output(exit);
	if (testing_file(ANIM_1, SPRITE_ACCESS_ERR_ANIM, &exit, &out))
		error_output(exit);
	if (testing_file(ANIM_2, SPRITE_ACCESS_ERR_ANIM, &exit, &out))
		error_output(exit);
	if (testing_file(ANIM_3, SPRITE_ACCESS_ERR_ANIM, &exit, &out))
		error_output(exit);
	if (out)
		return (testing_file(PATH_ERROR, ERR_XPM_FAIL, &exit, &out));
	return (0);
}

int	access_file_tester(t_map map, t_error exit)
{
	int	out;

	out = 0;
	if (testing_file(map.north_asset, SPRITE_ACCESS_ERR_NO, &exit, &out))
		error_output(exit);
	if (testing_file(map.south_asset, SPRITE_ACCESS_ERR_SO, &exit, &out))
		error_output(exit);
	if (testing_file(map.west_asset, SPRITE_ACCESS_ERR_WE, &exit, &out))
		error_output(exit);
	if (testing_file(map.east_asset, SPRITE_ACCESS_ERR_EA, &exit, &out))
		error_output(exit);
	if (BONUS == 0)
		return (0);
	if (testing_file(map.door_asset, SPRITE_ACCESS_ERR_D, &exit, &out))
		error_output(exit);
	return (access_anim_sprite(exit, out));
}
