/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colors_test.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/03 11:27:57 by nbacconn          #+#    #+#             */
/*   Updated: 2025/09/03 16:15:31 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	ft_atoi_rgb(char *str, int *i)
{
	int	cpt;
	int	nbr;

	cpt = 0;
	nbr = -1;
	while (ft_isdigit(str[*i]))
	{
		if (cpt == 0)
			nbr = 0;
		nbr = (nbr * 10) + (str[*i] - '0');
		(*i)++;
		cpt++;
		if (nbr < 0 || nbr > 255)
			return (-2);
	}
	return (nbr);
}

static int	r_and_b_test(t_game *game, int *i, int *color, char *str)
{
	*color = ft_atoi_rgb(str, i);
	if (*color == -1)
		return (new_error(&game->exit, FORMAT_COLOR_ERR), 1);
	if (*color == -2)
		return (new_error(&game->exit, NBR_COLOR_ERR), 1);
	if (str[*i] != ',')
		return (new_error(&game->exit, COMMA_ERR), 1);
	return (0);
}

static int	ceiling_color_test(t_game *game)
{
	int		i;

	i = 0;
	if (r_and_b_test(game, &i, &(game->map_info.ceiling_color.red),
			game->map_info.ceiling_color_str))
		return (1);
	i++;
	if (r_and_b_test(game, &i, &(game->map_info.ceiling_color.green),
			game->map_info.ceiling_color_str))
		return (1);
	i++;
	game->map_info.ceiling_color.blue
		= ft_atoi_rgb(game->map_info.ceiling_color_str, &i);
	if (game->map_info.ceiling_color.blue == -1)
		return (new_error(&game->exit, FORMAT_COLOR_ERR), 1);
	if (game->map_info.ceiling_color.blue == -2)
		return (new_error(&game->exit, NBR_COLOR_ERR), 1);
	if (game->map_info.ceiling_color_str[i] != '\0')
		return (new_error(&game->exit, END_COLOR_ERR), 1);
	return (0);
}

static int	floor_color_test(t_game *game)
{
	int		i;

	i = 0;
	if (r_and_b_test(game, &i, &(game->map_info.floor_color.red),
			game->map_info.floor_color_str))
		return (1);
	i++;
	if (r_and_b_test(game, &i, &(game->map_info.floor_color.green),
			game->map_info.floor_color_str))
		return (1);
	i++;
	game->map_info.floor_color.blue
		= ft_atoi_rgb(game->map_info.floor_color_str, &i);
	if (game->map_info.floor_color.blue == -1)
		return (new_error(&game->exit, FORMAT_COLOR_ERR), 1);
	if (game->map_info.floor_color.blue == -2)
		return (new_error(&game->exit, NBR_COLOR_ERR), 1);
	if (game->map_info.floor_color_str[i] != '\0')
		return (new_error(&game->exit, END_COLOR_ERR), 1);
	return (0);
}

int	color_tester(t_game *game)
{
	if (ceiling_color_test(game))
		return (1);
	if (floor_color_test(game))
		return (1);
	return (0);
}
