/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_checker_first.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/04 15:34:36 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/06 12:01:36 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	check_zero(char **file_tab, int i, int j, t_game *game)
{
	if ((i > 0 && (size_t)j > ft_strlen(file_tab[i - 1]))
		|| (file_tab[i + 1] != 0 && (size_t)j > ft_strlen(file_tab[i + 1])))
		return (new_error(&game->exit, ZERO_ERR), 1);
	if (i == 0 || j == 0
		|| file_tab[i + 1] == NULL || file_tab[i][j + 1] == '\0')
		return (new_error(&game->exit, ZERO_ERR), 1);
	if (!ft_isprint(file_tab[i + 1][j]) || file_tab[i + 1][j] == ' '
		|| !ft_isprint(file_tab[i][j + 1]) || file_tab[i][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j]) || file_tab[i - 1][j] == ' '
		|| !ft_isprint(file_tab[i][j - 1]) || file_tab[i][j - 1] == ' ')
		return (new_error(&game->exit, ZERO_ERR), 1);
	if (!ft_isprint(file_tab[i + 1][j + 1]) || file_tab[i + 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j + 1]) || file_tab[i - 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j - 1]) || file_tab[i - 1][j - 1] == ' '
		|| !ft_isprint(file_tab[i + 1][j - 1]) || file_tab[i + 1][j - 1] == ' ')
		return (new_error(&game->exit, CORNER_ERR), 1);
	return (0);
}

static int	check_direction(char **file_tab, int i, int j, t_game *game)
{
	if ((i > 0 && (size_t)j > ft_strlen(file_tab[i - 1]))
		|| (file_tab[i + 1] != 0 && (size_t)j > ft_strlen(file_tab[i + 1])))
		return (new_error(&game->exit, ZERO_ERR), 1);
	if (i == 0 || j == 0
		|| file_tab[i + 1] == NULL || file_tab[i][j + 1] == '\0')
		return (1);
	if (!ft_isprint(file_tab[i + 1][j]) || file_tab[i + 1][j] == ' '
		|| !ft_isprint(file_tab[i][j + 1]) || file_tab[i][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j]) || file_tab[i - 1][j] == ' '
		|| !ft_isprint(file_tab[i][j - 1]) || file_tab[i][j - 1] == ' ')
		return (1);
	if (!ft_isprint(file_tab[i + 1][j + 1]) || file_tab[i + 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j + 1]) || file_tab[i - 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j - 1]) || file_tab[i - 1][j - 1] == ' '
		|| !ft_isprint(file_tab[i + 1][j - 1]) || file_tab[i + 1][j - 1] == ' ')
		return (1);
	game->map_info.direction = file_tab[i][j];
	game->map_info.position.y = i;
	game->map_info.position.x = j;
	return (0);
}

static int	check_door(char **file_tab, int i, int j)
{
	if ((i > 0 && (size_t)j > ft_strlen(file_tab[i - 1]))
		|| (file_tab[i + 1] != 0 && (size_t)j > ft_strlen(file_tab[i + 1])))
		return (1);
	if (i == 0 || j == 0
		|| file_tab[i + 1] == NULL || file_tab[i][j + 1] == '\0')
		return (1);
	if (!ft_isprint(file_tab[i + 1][j]) || file_tab[i + 1][j] == ' '
		|| !ft_isprint(file_tab[i][j + 1]) || file_tab[i][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j]) || file_tab[i - 1][j] == ' '
		|| !ft_isprint(file_tab[i][j - 1]) || file_tab[i][j - 1] == ' ')
		return (1);
	if (!ft_isprint(file_tab[i + 1][j + 1]) || file_tab[i + 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j + 1]) || file_tab[i - 1][j + 1] == ' '
		|| !ft_isprint(file_tab[i - 1][j - 1]) || file_tab[i - 1][j - 1] == ' '
		|| !ft_isprint(file_tab[i + 1][j - 1]) || file_tab[i + 1][j - 1] == ' ')
		return (1);
	if ((file_tab[i + 1][j] == '1' && file_tab[i - 1][j] == '1'
		&& file_tab[i][j - 1] != '1' && file_tab[i][j + 1] != '1')
		|| (file_tab[i + 1][j] != '1' && file_tab[i - 1][j] != '1'
		&& file_tab[i][j - 1] == '1' && file_tab[i][j + 1] == '1'))
		return (0);
	return (1);
}

static int	check_map_design(char **file_tab, t_game *game)
{
	int	i;
	int	j;

	i = 0;
	while (file_tab[i])
	{
		j = 0;
		while (file_tab[i][j])
		{
			if (file_tab[i][j] == '\n')
				file_tab[i][j] = '\0';
			if (file_tab[i][j] == '0' && check_zero(file_tab, i, j, game))
				return (1);
			if ((file_tab[i][j] == 'N' || file_tab[i][j] == 'S'
				|| file_tab[i][j] == 'W' || file_tab[i][j] == 'E')
				&& (game->map_info.direction != '\0'
					|| check_direction(file_tab, i, j, game)))
				return (new_error(&game->exit, DIRECTION_ERR), 1);
			if (file_tab[i][j] == 'D' && check_door(file_tab, i, j))
				return (new_error(&game->exit, DOOR_ERR), 1);
			j++;
		}
		i++;
	}
	return (0);
}

int	check_map(char ***file_tab, t_game *game, int *i, int nb_lines)
{
	if (get_to_map_index(*file_tab, i, game))
		return (1);
	*file_tab = create_new_tab_map(*file_tab, i, nb_lines);
	if (!(*file_tab))
		return (1);
	if (check_wrong_char(*file_tab, "NSWE01\n ", game))
		return (1);
	if (check_map_design(*file_tab, game))
		return (1);
	if (game->map_info.direction == '\0')
		return (new_error(&game->exit, NO_SPAWN_ERR), 1);
	game->map_info.map = *file_tab;
	return (0);
}
