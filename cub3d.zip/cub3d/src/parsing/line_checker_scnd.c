/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   line_checker_scnd.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:54:03 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/13 16:34:32 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

int	free_infos_if_null(t_game *game)
{
	if (game->map_info.north_asset == NULL || game->map_info.south_asset == NULL
		|| game->map_info.west_asset == NULL
		|| game->map_info.east_asset == NULL
		|| game->map_info.floor_color_str == NULL
		|| game->map_info.ceiling_color_str == NULL
		|| (BONUS == 1 && game->map_info.door_asset == NULL))
	{
		if (game->map_info.north_asset)
			free(game->map_info.north_asset);
		if (game->map_info.south_asset)
			free(game->map_info.south_asset);
		if (game->map_info.west_asset)
			free(game->map_info.west_asset);
		if (game->map_info.east_asset)
			free(game->map_info.east_asset);
		if (game->map_info.floor_color_str)
			free(game->map_info.floor_color_str);
		if (game->map_info.ceiling_color_str)
			free(game->map_info.ceiling_color_str);
		if (game->map_info.door_asset)
			free(game->map_info.door_asset);
		return (1);
	}
	return (0);
}

int	tab_complete(int *tab)
{
	int	i;

	i = 0;
	while (i < 6 + BONUS)
	{
		if (tab[i] == 0)
			return (1);
		i++;
	}
	return (0);
}

int	door_line_checker(char **file_tab, char **line_tab,
		t_game *game, int *tab_check_infos)
{
	if (ft_strcmp(line_tab[0], "D") == 0)
	{
		if (tab_check_infos[6] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.door_asset = ft_strdup(line_tab[1]);
		tab_check_infos[6] = 1;
		return (0);
	}
	return (1);
}

int	jump_empty_lines(int *i, char ***line_tab, char ***file_tab, t_game *game)
{
	(*i)++;
	free_tab(*line_tab);
	if (!((*file_tab)[*i]))
		return (new_error(&game->exit, NORM_INFO_ERR), free_tab(*file_tab), 1);
	*line_tab = ft_split_whitespaces((*file_tab)[*i]);
	if (!*line_tab)
		return (free_tab(*file_tab), 1);
	return (0);
}
