/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:45:04 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/16 17:54:15 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	count_lines(char *av[])
{
	int		fd;
	int		cpt;
	char	*line;

	fd = open(av[1], O_RDONLY);
	if (fd == -1)
		return (-1);
	cpt = 0;
	line = get_next_line(fd);
	if (!line)
		return (0);
	while (line)
	{
		free(line);
		line = get_next_line(fd);
		cpt++;
	}
	close(fd);
	return (cpt);
}

int	parsing(char *av[], t_game *game)
{
	int		i;
	int		nb_lines;
	char	**file_tab;

	i = 0;
	nb_lines = count_lines(av);
	if (nb_lines == -1)
		return (1);
	file_tab = create_file_tab(av, nb_lines);
	if (!file_tab)
		return (1);
	if (check_info_lines(file_tab, game, &i) == 1)
		return (1);
	if (access_file_tester(game->map_info, game->exit))
		return (free_tab(file_tab), 1);
	if (color_tester(game))
		return (free_tab(file_tab), 1);
	if (check_map(&file_tab, game, &i, nb_lines) == 1)
		return (free_tab(file_tab), 1);
	return (0);
}
