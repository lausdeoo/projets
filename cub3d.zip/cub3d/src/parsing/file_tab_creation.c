/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_tab_creation.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:50:00 by nbacconn          #+#    #+#             */
/*   Updated: 2025/09/19 09:50:41 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

char	**create_file_tab(char *av[], int nb_lines)
{
	char	**tab;
	char	*line;
	int		i;
	int		fd;

	fd = open(av[1], O_RDONLY);
	if (fd == -1)
		return (NULL);
	tab = malloc((nb_lines + 1) * sizeof(char *));
	if (!tab)
		return (close(fd), NULL);
	tab[nb_lines] = NULL;
	line = get_next_line(fd);
	i = 0;
	while (line)
	{
		tab[i] = ft_strdup(line);
		if (!tab[i])
			return (close(fd), free_tab_index((void **)tab, i), NULL);
		i++;
		free(line);
		line = get_next_line(fd);
	}
	close(fd);
	return (tab);
}
