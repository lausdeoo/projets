/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   line_checker_first.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:53:53 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/13 16:34:35 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	first_lines_checker(char **file_tab, char **line_tab,
		t_game *game, int *tab_check_infos)
{
	if (ft_strcmp(line_tab[0], "NO") == 0)
	{
		if (tab_check_infos[0] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.north_asset = ft_strdup(line_tab[1]);
		tab_check_infos[0] = 1;
		return (0);
	}
	if (ft_strcmp(line_tab[0], "SO") == 0)
	{
		if (tab_check_infos[1] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.south_asset = ft_strdup(line_tab[1]);
		tab_check_infos[1] = 1;
		return (0);
	}
	if (ft_strcmp(line_tab[0], "WE") == 0)
	{
		if (tab_check_infos[2] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.west_asset = ft_strdup(line_tab[1]);
		tab_check_infos[2] = 1;
		return (0);
	}
	return (1);
}

static int	last_lines_checker(char **file_tab, char **line_tab,
		t_game *game, int *tab_check_infos)
{
	if (ft_strcmp(line_tab[0], "EA") == 0)
	{
		if (tab_check_infos[3] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.east_asset = ft_strdup(line_tab[1]);
		tab_check_infos[3] = 1;
		return (0);
	}
	if (ft_strcmp(line_tab[0], "F") == 0)
	{
		if (tab_check_infos[4] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.floor_color_str = ft_strdup(line_tab[1]);
		tab_check_infos[4] = 1;
		return (0);
	}
	if (ft_strcmp(line_tab[0], "C") == 0)
	{
		if (tab_check_infos[5] == 1)
			return (free_tab(file_tab), -1);
		game->map_info.ceiling_color_str = ft_strdup(line_tab[1]);
		tab_check_infos[5] = 1;
		return (0);
	}
	return (1);
}

static int	check_result(char **file_tab, char **line_tab,
		t_game *game, int *tab_check_infos)
{
	int	check_result_first;
	int	check_result_last;
	int	check_result_door;

	check_result_first = first_lines_checker(file_tab, line_tab,
			game, tab_check_infos);
	check_result_last = last_lines_checker(file_tab, line_tab,
			game, tab_check_infos);
	if (BONUS == 1)
		check_result_door = door_line_checker(file_tab, line_tab,
				game, tab_check_infos);
	if (check_result_first == -1 || check_result_last == -1
		|| (BONUS == 1 && check_result_door == -1))
		return (new_error(&game->exit, INFO_REPET), free_tab(file_tab), 1);
	if ((check_result_first == 1 && check_result_last == 1
			&& BONUS == 0)
		|| (check_result_first == 1 && check_result_last == 1
			&& BONUS == 1 && check_result_door == 1))
		return (new_error(&game->exit
				, NORM_INFO_ERR), free_tab(file_tab), 1);
	return (0);
}

static int	check_each_line(char **file_tab, t_game *game,
		int *i, int *tab_check_infos)
{
	char	**line_tab;

	while (tab_complete(tab_check_infos))
	{
		if (!file_tab[*i])
			return (new_error(&game->exit, NORM_INFO_ERR),
				free_tab(file_tab), 1);
		line_tab = ft_split_whitespaces(file_tab[*i]);
		if (!line_tab)
			return (free_tab(file_tab), 1);
		while (line_tab[0] == NULL)
			jump_empty_lines(i, &line_tab, &file_tab, game);
		if (line_tab[1] == NULL || line_tab[2] != NULL)
			return (new_error(&game->exit, NORM_INFO_ERR),
				free_tab(line_tab), free_tab(file_tab), 1);
		if (check_result(file_tab, line_tab, game, tab_check_infos))
			return (free_tab(line_tab), 1);
		free_tab(line_tab);
		(*i)++;
	}
	return (0);
}

int	check_info_lines(char **file_tab, t_game *game, int *i)
{
	int	*tab;

	tab = malloc(sizeof(int) * (6 + BONUS));
	if (!tab)
		return (free_tab(file_tab), 1);
	*i = 0;
	while (*i < 6 + BONUS)
		tab[(*i)++] = 0;
	*i = 0;
	if (check_each_line(file_tab, game, i, tab))
		return (free(tab), 1);
	if (free_infos_if_null(game) == 1)
		return (free_tab(file_tab), free(tab), 1);
	free(tab);
	return (0);
}
