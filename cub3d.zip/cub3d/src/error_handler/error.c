/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 12:27:58 by tcros             #+#    #+#             */
/*   Updated: 2025/09/24 11:45:58 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cube3d.h"

static int	check_param(int ac, char *av[], t_game *game)
{
	if (ac != 2)
		return (new_error(&game->exit, USAGE));
	if (extension_verif(av, &(game->exit)) == 1)
		return (1);
	return (0);
}

int	new_error(t_error *error, char *err)
{
	ft_strlcpy(error->sub_err, err, 200);
	if (errno)
		error->out = errno;
	else
		error->out = 1;
	return (1);
}

void	error_output(t_error err)
{
	ft_putendl_fd("Error", STDERR_FILENO);
	ft_putstr_fd(err.err, STDERR_FILENO);
	if (errno)
		perror(err.sub_err);
	else
		ft_putendl_fd(err.sub_err, STDERR_FILENO);
}

void	check_for_error(int ac, char *av[], t_game *game)
{
	if (check_param(ac, av, game))
	{
		ft_strlcpy(game->exit.err, PARAM_ERR, 200);
		if (!game->exit.out)
			game->exit.out = EXIT_FAILURE;
		exit_all(game, -1);
	}
	if (parsing(av, game) == 1)
	{
		ft_strlcpy(game->exit.err, PARSE_ERR, 200);
		if (!game->exit.out)
			game->exit.out = EXIT_FAILURE;
		exit_all(game, -1);
	}
}
