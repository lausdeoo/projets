/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 12:21:44 by tcros             #+#    #+#             */
/*   Updated: 2025/10/17 10:22:53 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ERROR_H
# define ERROR_H

// Declaration avancee de la structure t_game
typedef struct s_game	t_game;

// Erreur Globale
# define PARAM_ERR "Invalid parameter : "
# define SCREEN_ERR "An error has occured while rendering : "
# define PARSE_ERR "An error has occured while parsing the map : "
# define USAGE "Usage: ./cub3d <map_name>.cub"

// Erreur Ecran
# define MLX_INIT_FAIL "Initialisation of mlx failed."
# define NEW_WIN_FAIL "Fails to create a new window : "
# define NEW_IMG_FAIL "Fails to create a new frame : "
# define NEW_MMAP_FAIL "Fails to create the minimap : "

// Erreur fichiers xpm
# define NORTH_XPM_FAIL "Fails to transform NORTH xpm file to image"
# define SOUTH_XPM_FAIL "Fails to transform SOUTH xpm file to image"
# define WEST_XPM_FAIL "Fails to transform WEST xpm file to image"
# define EAST_XPM_FAIL "Fails to transform EAST xpm file to image"
# define DOOR_XPM_FAIL "Fails to transform DOOR xpm file to image"
# define ANIM_XPM_FAIL "Fails to transform ANIM xpm file to image"
# define ERR_XPM_FAIL "Fails to transform ERROR xpm file to image"
# define PATH_ERROR "assets/.Error.xpm"

// Erreur Parsing
# define BAD_FORMAT "Bad format file"

///// PARSING ERROR /////

// Lines error
# define INFO_REPET "Information repetition"
# define NORM_INFO_ERR "Norm information error (missing or too much)"

// No map
# define NO_MAP "No map in file"

// Sprite access error
# define SPRITE_ACCESS_ERR_NO "Cannot access the North sprite file"
# define SPRITE_ACCESS_ERR_SO "Cannot access the South sprite file"
# define SPRITE_ACCESS_ERR_WE "Cannot access the West sprite file"
# define SPRITE_ACCESS_ERR_EA "Cannot access the East sprite file"
# define SPRITE_ACCESS_ERR_D "Cannot access the Door sprite file"
# define SPRITE_ACCESS_ERR_ANIM "Cannot access one of the Animation sprite file"

// Color error
# define FORMAT_COLOR_ERR "Invalid character in a color string"
# define COMMA_ERR "Colors must be separated by (one) comma, nothing else"
# define END_COLOR_ERR "Invalid character at the end of a color string"
# define NBR_COLOR_ERR "Colors must be between 0 and 255" 

// Map error

# define WRONG_CHAR_MAP "Invalid char in map"
# define ZERO_ERR "Invalid placement of the character '0'"
# define CORNER_ERR "There must be a '1' in each corner of the map"
# define DIRECTION_ERR "Invalid placement or multiple direction indicator"
# define DOOR_ERR "Invalid placement of a door (no access or not enough walls)"
# define NO_SPAWN_ERR "No spawn point found"

// Structure error
typedef struct s_error
{
	char	err[200];
	char	sub_err[200];
	int		out;
}	t_error;

//error.c
int		new_error(t_error *error, char *err);
void	error_output(t_error error);
void	check_for_error(int ac, char *av[], t_game *game);

#endif
