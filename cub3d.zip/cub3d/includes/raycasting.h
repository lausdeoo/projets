/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/03 14:57:33 by tcros             #+#    #+#             */
/*   Updated: 2025/10/14 10:16:07 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RAYCASTING_H
# define RAYCASTING_H

// Declaration avancee de la structure t_game
typedef struct s_game	t_game;
typedef struct s_screen	t_screen;
typedef struct s_img	t_img;
typedef struct s_tex	t_tex;
typedef struct s_player	t_player;

// A but de test
# define RGB_WALL 0x606060

// Structure Point
typedef struct s_point
{
	int	x;
	int	y;
}	t_point;

// Structure Vector
typedef struct s_vector
{
	double	x;
	double	y;
}	t_vector;

// Structure RGB
typedef struct s_rgb
{
	unsigned char	t;
	unsigned char	r;
	unsigned char	g;
	unsigned char	b;
}	t_rgb;

// Structure Raycast
typedef struct s_ray
{
	t_vector	dir;
	t_vector	delta_dist;
	t_vector	side_dist;
	t_vector	camera;
	t_point		map_pos;
	t_point		step;
	double		perpwalldist;
	int			side;
	char		touched_char;
}	t_ray;

//raycasting_doors.c
void			door_calculation(t_ray *ray, char **map,
					int *hit, t_game *game);

//calculations.c
unsigned int	rgb_to_int(t_rgb color);

//raycasting.c
void			raycasting(t_ray *ray, t_game *game);
void			left_side_dist(t_ray *ray, double pos, char c);
void			right_side_dist(t_ray *ray, double pos, char c);
double			deg_to_rad(double deg);

//draw_col.c
void			draw_col_h(int *y, int line_h, t_screen *screen, int pos);
void			draw_col_m(int *y, t_screen *screen, int pos, t_tex tex);
void			draw_col_l(int *y, t_screen *screen, int pos);

#endif
