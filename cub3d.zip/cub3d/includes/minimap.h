/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minimap.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 15:05:04 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 16:49:07 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINIMAP_H
# define MINIMAP_H

//structure avance de t_game, t_player, t_screen et t_img
typedef struct s_game	t_game;
typedef struct s_screen	t_screen;
typedef struct s_img	t_img;
typedef struct s_player	t_player;
typedef struct s_map	t_map;

// Macro relatif a la taille de la minimap
# define MMAP_H 350
# define MMAP_W 350
# define CUR_HEIGHT 10
# define CUR_LENGTH 10
# define LITTLE_M -20
# define MMAP_OFFSET 25
# define CASE_SIZE 32
# define OUTLINE 2000

// Macro relatif a la couleur de la minimap
# define MMAP_T 192
# define MMAP_R 128
# define MMAP_G 128
# define MMAP_B 128
// OUTLINE
# define OUT_T 255
# define OUT_R 255
# define OUT_G 255
# define OUT_B 255

// Macro relatif a la couleur du curseur
# define PLAY_T 255
# define PLAY_R 255
# define PLAY_G 0
# define PLAY_B 0

// Macro relatif a la couleur des MURS
# define WALL_T 255
# define WALL_R 255
# define WALL_G 255
# define WALL_B 255
# define DOORC_R 222
# define DOORC_G 057
# define DOORC_B 24
# define DOORO_R 24
# define DOORO_G 222
# define DOORO_B 57

//minimap.c
void	minimap(t_screen *screen, t_img *minimap, t_game *game);

//drawing_mmap.c
void	draw_minimap(t_screen *screen, t_point pos, int center);

//drawing_player.c
void	draw_player(t_player *player, t_screen *screen, t_point pos);

//drawing_walls.c
void	draw_walls(t_player *player, t_screen *screen, t_point pos, t_map *map);

//handle_color.c
void	my_mlx_pixel_put_alpha(t_img *img, int x, int y, unsigned int color);

#endif
