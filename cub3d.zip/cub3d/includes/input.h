/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 11:55:37 by tcros             #+#    #+#             */
/*   Updated: 2025/10/14 10:05:14 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef INPUT_H
# define INPUT_H

// Declaration avancee de la structure t_game
typedef struct s_game	t_game;

// Touches du clavier
# define ESC_KEY 65307
# define W_KEY 119
# define A_KEY 97
# define S_KEY 115
# define D_KEY 100
# define SHIFT_KEY 65505
# define RARROW_KEY 65363
# define LARROW_KEY 65361
# define SHIFT_KEY 65505
# define SPACE_KEY 32

//input.c
int		input_handler(t_game *game);

// movement.c
void	movement(t_game *game, char **map);

// looking.c
void	looking(t_game *game);

#endif
