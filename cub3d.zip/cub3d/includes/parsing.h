/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:54:45 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/14 10:16:58 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSING_H
# define PARSING_H

typedef struct s_error	t_error;
typedef struct s_game	t_game;

// Structure couleurs
typedef struct s_color
{
	int	red;
	int	green;
	int	blue;
}	t_color;

// Structure map info
typedef struct s_map
{
	char	**map;
	char	*north_asset;
	char	*south_asset;
	char	*east_asset;
	char	*west_asset;
	char	*ceiling_color_str;
	char	*floor_color_str;
	char	*door_asset;
	t_color	ceiling_color;
	t_color	floor_color;
	t_point	position;
	char	direction;
	int		h;
	int		*w;
}	t_map;

// extension.c
int			extension_verif(char *av[], t_error *exit);

// ft_split_whitespaces.c
char		**ft_split_whitespaces(char *string);

// file_tab_creation.c
char		**create_file_tab(char *av[], int nb_lines);

// line_checker_first.c
int			check_info_lines(char **file_tab, t_game *game, int *i);

// line_checker_scnd.c
int			free_infos_if_null(t_game *game);
int			tab_complete(int *tab);
int			door_line_checker(char **file_tab, char **line_tab,
				t_game *game, int *tab_check_infos);
int			jump_empty_lines(int *i, char ***line_tab,
				char ***file_tab, t_game *game);

// parsing.c
int			parsing(char *av[], t_game *game);

// sprite_files_test
int			access_file_tester(t_map map, t_error exit);

// colors_test.c
int			color_tester(t_game *game);

// map_checker_first.c
int			check_map(char ***file_tab, t_game *game, int *i, int nb_lines);

// map_checker_scnd.c
int			get_to_map_index(char **file_tab, int *i, t_game *game);
char		**create_new_tab_map(char **file_tab, int *i, int nb_lines);
int			ft_strfind_charset_ws(char *str, char *charset);
int			check_wrong_char(char **file_tab, char *charset, t_game *game);

#endif
