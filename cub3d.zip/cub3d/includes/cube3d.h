/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cube3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcros <tcros@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 11:57:13 by tcros             #+#    #+#             */
/*   Updated: 2025/10/16 14:52:58 by tcros            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUBE3D_H
# define CUBE3D_H

// Includes obligatoires
# include <stdlib.h>
# include <stdio.h>
# include <fcntl.h>
# include <errno.h>
# include <math.h>
# include "mlx.h"

// Includes personnelles
# include "libft.h"
# include "raycasting.h"
# include "error.h"
# include "screen.h"
# include "minimap.h"
# include "input.h"
# include "parsing.h"
# include "doors.h"

// Macro BONUS
# ifndef BONUS
#  define BONUS 0
# endif

// Macro pour le Player
# define MOVE_SPEED 0.015;
# define ROTATION_SPEED 0.02;
# define MAX_ROT 0.10

// Macro Animation
# define ANIM_0 "assets/anim_0.xpm"
# define ANIM_1 "assets/anim_1.xpm"
# define ANIM_2 "assets/anim_2.xpm"
# define ANIM_3 "assets/anim_3.xpm"

// Macro QoL
# define WDIST 0.05

// Structure du joueur
typedef struct s_player
{
	t_vector	pos;
	t_vector	dir;
	t_vector	plane;
	t_rgb		color;
	double		mov_sp;
	double		rot_sp;
	int			w_key;
	int			a_key;
	int			s_key;
	int			d_key;
	int			ra_key;
	int			la_key;
	int			space_key;
}	t_player;

// Structure globale du Jeu
typedef struct s_game
{
	t_error		exit;
	t_screen	screen;
	t_player	player;
	t_map		map_info;
}	t_game;

// cube3d.c
int		exit_all(t_game *game, int exit_out);
int		cube3d(int ac, char *av[]);

// utils.c
int		ft_strcmp(char *s1, char *s2);
int		handle_image(t_img *imgfail, t_screen *screen);

// free.c
void	free_tab_index(void **tab, int i);
void	free_tab(char **tab);
void	destroy_sprite_images(t_game *game);
void	free_map(t_game *game);
void	free_doors(t_game *game, t_screen screen);

#endif
