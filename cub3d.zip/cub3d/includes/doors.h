/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   doors.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nbacconn <nbacconn@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 11:22:47 by nbacconn          #+#    #+#             */
/*   Updated: 2025/10/14 10:05:53 by nbacconn         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DOORS_H
# define DOORS_H

# include "parsing.h"

typedef struct s_player	t_player;

# define FRAME_DOOR_OPENING 31
# define DOOR_CLOSED 0
# define DOOR_OPEN FRAME_DOOR_OPENING
# define NOT_A_DOOR -FRAME_DOOR_OPENING

// doors.c
void	doors_update(t_screen *screen, t_player *player, t_map *map);

// doors_scnd.c
int		**copy_map_doors(char **map);

#endif
