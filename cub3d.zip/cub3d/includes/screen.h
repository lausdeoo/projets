/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   screen.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yucheng <yucheng@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 11:25:34 by tcros             #+#    #+#             */
/*   Updated: 2025/10/17 18:51:36 by yucheng          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCREEN_H
# define SCREEN_H

// Declaration avancee de la structure t_game et t_ray
typedef struct s_game	t_game;
typedef struct s_ray	t_ray;

// Macro relatif a la fenetre
# define HEIGHT 1080
# define WIDTH 1920

// Field of View du player
# define FOV 70
# define PITCH 17

// Animation Rate
# define ANIM_RATE 3

// Structure img
typedef struct s_img
{
	void	*img;
	char	*addr;
	int		bpp;
	int		stride;
	int		endian;
	int		width;
	int		height;
}	t_img;

typedef struct s_tex
{
	int		tex_x;
	int		tex_y;
	int		line_h;
	t_img	texture;
}	t_tex;

// Structure stockage portes
typedef struct s_tab_door
{
	t_img	door_img;
	int		**doors_map;
}	t_tab_door;

typedef struct s_anim
{
	t_img		anim_img[4];
	int			anim_state;
	int			anim_cpt;

}	t_anim;

// Structure screen
typedef struct s_screen
{
	void		*win;
	void		*mlx;
	t_img		frame;
	t_rgb		floor_color;
	t_rgb		ceil_color;
	t_img		north_img;
	t_img		south_img;
	t_img		west_img;
	t_img		east_img;
	t_tab_door	door;
	t_anim		anim;
	int			pitch;
	int			h;
	int			w;
	int			mmap_w;
	int			mmap_h;
}	t_screen;

// screen.c
void	launch_screen(t_game *game);

// texture_init.c
int		init_tex(t_screen *screen, t_game *game);

// render.c
int		render(t_game *game);

//drawing.c
void	my_mlx_pixel_put(t_img *frame, int x, int y, unsigned int color);
void	drawing(int pos, t_ray *ray, t_game *game, int **doors_map);

//minimap.c
void	minimap(t_screen *screen, t_img *minimap, t_game *game);

#endif
