#pragma once

#include <iostream>
#include <algorithm>
#include <string>
#include <stack>

class RPN
{
	private:
		std::stack<double>		_myStack;
	public:
	//Canonical form
		RPN();
		RPN(RPN const &copy);
		RPN& operator=(RPN const &copy);
		virtual ~RPN();
	//Getter
		double getMyStack();
	//Other member functions
		int calculate(std::string line);
		std::string parsing(char *line);
};
