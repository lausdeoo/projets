#include "RPN.hpp"
//Canonical form
RPN::RPN()
{}

RPN::RPN(RPN const &copy)
{
	if (this != &copy)
		*this = copy;
}

RPN& RPN::operator=(RPN const &copy)
{
	this->_myStack = copy._myStack;
	return (*this);
}

RPN::~RPN()
{}

//Getter
double RPN::getMyStack()
{
	return (this->_myStack.top());
}

//Other member functions
std::string RPN::parsing(char *line)
{
	std::string new_line;
	int i = 0;

	while (line[i])
	{
		while (line[i] == ' ')
			i++;
		if ((line[i] < '0' || line[i] > '9') && line[i] != '+' && line[i] != '-' && line[i] != '/' && line[i] != '*')
			return ("");
		if (line[i] >= '0' && line[i] <= '9')
		{
			if (line[i + 1] >= '0' && line[i + 1] <= '9')
				return ("");
		}
		new_line.push_back(line[i]);
		i++;
	}
	if ((line[i - 1] >= '0' && line[i - 1] <= '9'))
		return ("");
	return (new_line);
}

//parcours la ligne, stocke les nbs dans la stack jusqu'a rencontrer un operateur
//operateur rencontre: on pop les deux derniers nbs, on leur applique l'operateur, et on met le resultat dans la stack
//attention a la division par 0
int RPN::calculate(std::string line)
{
	int i = 0;
	double value1;
	double value2;
	double tot;

	while (line[i])
	{
		while (line[i] != '+' && line[i] != '-' && line[i] != '/' && line[i] != '*')
		{
			this->_myStack.push(line[i] - '0');
			i++;
		}
		if (this->_myStack.size() < 2)
		{
			std::cerr << "Error" << std::endl;
			return (1);
		}
		value2 = this->_myStack.top();
		this->_myStack.pop();
		value1 = this->_myStack.top();
		this->_myStack.pop();
		if (line[i] == '+')
			tot = value1 + value2;
		if (line[i] == '-')
			tot = value1 - value2;
		if (line[i] == '*')
			tot = value1 * value2;
		if (line[i] == '/')
		{
			if (value2 == 0)
			{
				std::cerr << "Error: division by 0" << std::endl;
				return (1);
			}
			tot = value1 / value2;
		}
		this->_myStack.push(tot);
		i++;
	}
	return (0);
}