#include "RPN.hpp"

int main(int argc, char **argv)
{
	RPN rpn;
	std::string line;
	if (argc != 2)
	{
		std::cerr << "Error: this program takes one inverted Polish mathematical expression as argument." << std::endl;
		return (1);
	}
	line = rpn.parsing(argv[1]);
	if (line.empty())
	{
		std::cerr << "Error: wrong input" << std::endl;
		return (1);
	}
	if (rpn.calculate(line))
		return (1);
	std::cout << rpn.getMyStack() << std::endl;
}
