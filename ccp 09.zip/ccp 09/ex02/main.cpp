#include "PmergeMe.hpp"

int main(int argc, char **argv)
{
	if (argc < 2)
	{
		std::cerr << "Need I least one argument to sort" << std::endl;
		return (1);
	}
	try
	{
		clock_t time_start;
		clock_t time_end;
		double  timer;

		Pmergeme merge(argc);
		merge.initialize(argv);

		//vector
		time_start = clock();
		merge.sort(1);
		time_end = clock();
		timer = static_cast<double>(time_end - time_start) / CLOCKS_PER_SEC;

		//deque
		merge.setTime(1, timer);
		time_start = clock();
		merge.sort(2);
		time_end = clock();
		timer = static_cast<double>(time_end - time_start) / CLOCKS_PER_SEC;
		merge.setTime(2, timer);

		merge.display(argv);
	}
	catch(const std::exception& e)
	{
		std::cerr << e.what() << '\n';
	}
	
}
