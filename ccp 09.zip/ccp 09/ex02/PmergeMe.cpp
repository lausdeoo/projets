#include "PmergeMe.hpp"

//Canonical form
Pmergeme::Pmergeme(): _size(0), _maxPairSize(0), _vecTime(0), _deqTime(0)
{}

Pmergeme::Pmergeme(Pmergeme &copy)
{
	if (this != &copy)
		*this = copy;
}

Pmergeme& Pmergeme::operator=(Pmergeme &copy)
{
	this->_size = copy._size;
	this->_deqNumbers = copy._deqNumbers;
	this->_deqTime = copy._deqTime;
	this->_vecNumbers = copy._vecNumbers;
	this->_vecTime = copy._vecTime;

	return (*this);
}

Pmergeme::~Pmergeme()
{}

Pmergeme::Pmergeme(int ac): _size(ac - 1), _maxPairSize(0), _vecTime(0), _deqTime(0)
{}

//Getter and Setter
void Pmergeme::setTime(int i, double time)
{
	if (i == 1)
		this->_vecTime = time;
	else
		this->_deqTime = time;
}

//Methods

//------------------------Common parts for vector and deque------------------------

//checking the input and storing numbers in our containers
void Pmergeme::initialize(char **argv)
{
	long n = 0;

	for (int i = 1; i < (this->_size + 1); i++)
	{
		n = strtol(argv[i], NULL, 10);
		for (size_t j = 0; j < strlen(argv[i]); j++)
		{
			if (isalpha(argv[i][j]))
				throw WrongInputException();
		}
		if (n < 0 || n > 2147483647)
			throw WrongInputException();
		this->_vecNumbers.push_back(n);
		this->_deqNumbers.push_back(n);
	}

	for (std::vector<int>::iterator itv = this->_vecNumbers.begin(); itv != this->_vecNumbers.end(); itv++)
	{
		if (itv + 1 == this->_vecNumbers.end())
			break ;
		if (std::find((itv + 1), this->_vecNumbers.end(), *itv) != this->_vecNumbers.end())
			throw WrongInputException();
	}
}

//begin the sorting
void Pmergeme::sort(int i)
{
	if (this->_size == 1 || (this->_size == 2 && this->_vecNumbers[0] < this->_vecNumbers[1]))
		return ;

	if (this->_size == 2 && i == 1)
	{
		int tmp;
		tmp = this->_vecNumbers[0];
		this->_vecNumbers[0] = this->_vecNumbers[1];
		this->_vecNumbers[1] = tmp;
	}
	else if (this->_size == 2 && i == 2)
	{
		int tmp;
		tmp = this->_deqNumbers[0];
		this->_deqNumbers[0] = this->_deqNumbers[1];
		this->_deqNumbers[1] = tmp;

		return ;
	}

	if (i == 1)
		sortVect();
	else 
		sortDeq();
}

void Pmergeme::display(char **argv)
{
	std::cout << "Before: ";
	for (int i = 1; i < (this->_size + 1); i++)
		std::cout << argv[i] << " ";
	std::cout << std::endl;

	std::cout << "Vector after: ";
	if (isSorted(1) == true)
		std::cout << GREEN;
	else
		std::cout << RED;
	for (int j = 0; j < this->_size; j++)
		std::cout << this->_vecNumbers[j] << " ";
	std::cout << RESET << std::endl;

	std::cout << "Deque after: ";
	if (isSorted(2)  == true)
		std::cout << GREEN;
	else
		std::cout << RED;
	for (int j = 0; j < this->_size; j++)
		std::cout << this->_deqNumbers[j] << " ";
	std::cout << RESET << std::endl;

	std::cout << "Time to process a range of " << this->_size << " elements with std::vector : " << std::fixed << std::setprecision(5) << this->_vecTime << " us" << std::endl;
	std::cout << "Time to process a range of " << this->_size << " elements with std::deque : " << std::fixed << std::setprecision(5) << this->_deqTime << " us" << std::endl;
}

//getting the Jacobsthal number for the insertion
static int jacobsthalNumber(int index)
{
	if (index == 0)
		return (0);
	if (index == 1)
		return (1);
	if (index == 2)
		return (1);
	return (jacobsthalNumber(index - 1) + 2 * jacobsthalNumber(index - 2));
}

bool Pmergeme::isSorted(int i)
{
	if (i == 1)
	{
		std::vector<int>::iterator it;
		std::vector<int>::iterator second = this->_vecNumbers.begin();
	
		for (it = this->_vecNumbers.begin(); (second + 1) != this->_vecNumbers.end(); it++)
		{
			second++;
			if (*it > *second)
				return (false);
		}
		return (true);
	}
	else
	{
		std::deque<int>::iterator it;
		std::deque<int>::iterator second = this->_deqNumbers.begin();
	
		for (it = this->_deqNumbers.begin(); (second + 1) != this->_deqNumbers.end(); it++)
		{
			second++;
			if (*it > *second)
				return (false);
		}
		return (true);
	}
}

//------------------------Algo for vectors------------------------

void Pmergeme::sortVect()
{
	pairUp_vec(1);
	int pairSize = this->_maxPairSize;

	while (pairSize >= 1)
	{
		if (pairSize == 0)
			pairSize = 2;
		creatingMainPend_vec(pairSize);
		insertion_vec(pairSize);
		this->_vecMain.clear();
		this->_vecPend.clear();
		this->_vecNotParticiping.clear();
		pairSize /= 2;
	}
}

static void swapPairs_vec(std::vector<int>::iterator it, int power)
{
	for (int i = 0; i < power; i++)
	{
		std::iter_swap(it, (it + power));
		it++;
	}
}

//pairing numbers recursively and doing a first sort
//careful not to take the last numbers in case of an odd total
void Pmergeme::pairUp_vec(int power)
{
	int pairSize = 2 * power;
	int nbPairs = this->_size / pairSize;

	if (nbPairs < 1)
	{
		this->_maxPairSize = pairSize / 4;
		return ;
	}
	
	std::vector<int>::iterator it;
	std::vector<int>::iterator end = this->_vecNumbers.begin() + nbPairs * pairSize;

	for(it = this->_vecNumbers.begin(); it != end; std::advance(it, pairSize))
	{
		if (*(it + power - 1) > *(it + pairSize - 1))
			swapPairs_vec(it, power);
	}

	pairUp_vec(power * 2);
}

void Pmergeme::creatingMainPend_vec(int pairSize)
{
	int i = 0;
	int j = 0;

	while (i < (pairSize * 2))
	{
		this->_vecMain.push_back(this->_vecNumbers[i]);
		i++;
	}
	if ((i + pairSize) <= this->_size)
	{
		while (j < pairSize)
		{
			this->_vecPend.push_back(this->_vecNumbers[i]);
			j++;
			i++;
		}
	}
	while (i + (pairSize * 2) <= this->_size)
	{
		j = 0;
		while (j < pairSize)
		{
			this->_vecMain.push_back(this->_vecNumbers[i]);
			j++;
			i++;
		}
		j = 0;
		while (j < pairSize)
		{
			this->_vecPend.push_back(this->_vecNumbers[i]);
			j++;
			i++;
		}
	}
	while (i < this->_size)
	{
		this->_vecNotParticiping.push_back(this->_vecNumbers[i]);
		i++;
	}
}

void Pmergeme::insertion_vec(int pairSize)
{
	int		toInsert = 0;
	int		comparaison = 0;
	int		i = 3;
	int 	j;
	int		index = jacobsthalNumber(i);
	int		previousIndex = 1;
	size_t	position;

	std::vector<int>::iterator inserting_start;
	std::vector<int>::iterator inserting_end;
	std::vector<int>::iterator place;

	while (this->_vecPend.empty() == false)
	{
		position = (index + (index - 1)) * pairSize - 1;
		if (position <= this->_vecNumbers.size() - this->_vecNotParticiping.size())
			toInsert = this->_vecNumbers[position];
		else
			toInsert = this->_vecPend.back();
		inserting_end = std::find(this->_vecPend.begin(), this->_vecPend.end(), toInsert);
		if (inserting_end != this->_vecPend.end())	
			inserting_end++;
		inserting_start = inserting_end - pairSize;

		j = 0;
		while ((index - j) > previousIndex && inserting_start >= this->_vecPend.begin())
		{
			if (toInsert == this->_vecNumbers.back() || position + pairSize >= this->_vecNumbers.size() - this->_vecNotParticiping.size())
			{
				comparaison = this->_vecMain.back();
				place = this->_vecMain.end();
			}
			else
			{
				comparaison = this->_vecNumbers[position + pairSize];
				place = std::find(this->_vecMain.begin(), this->_vecMain.end(), comparaison) + 1;
			}

			if (comparaison == this->_vecMain.back() && comparaison > toInsert)
				place -= pairSize;
			while ((place - pairSize) >= this->_vecMain.begin() && *(place - 1) > toInsert && place != this->_vecMain.end())
				place -= pairSize;
			if (place < this->_vecMain.begin())
				place = this->_vecMain.begin();
			
			this->_vecMain.insert(place, inserting_start, inserting_end);
			inserting_start -= pairSize;
			inserting_end -= pairSize;
			if (inserting_start >= this->_vecPend.begin())
				toInsert = *(inserting_end - 1);
			j++;
		}

		if (std::distance(this->_vecPend.begin(), (this->_vecPend.begin() + j * pairSize)) >= (long)this->_vecPend.size())
		{
			this->_vecPend.clear();
			break ;
		}
		else		
			this->_vecPend.erase(this->_vecPend.begin(), (this->_vecPend.begin() + j * pairSize));

		i++;
		previousIndex = index;
		index = jacobsthalNumber(i);
	}
	this->_vecNumbers = this->_vecMain;
	if (this->_vecNotParticiping.empty() == false)
		this->_vecNumbers.insert(this->_vecNumbers.end(), this->_vecNotParticiping.begin(), this->_vecNotParticiping.end());
}

//https://dev.to/emuminov/human-explanation-and-step-by-step-visualisation-of-the-ford-johnson-algorithm-5g91

//------------------------Algo for deques------------------------

void Pmergeme::sortDeq()
{
	pairUp_deq(1);
	int pairSize = this->_maxPairSize;

	while (pairSize >= 1)
	{
		if (pairSize == 0)
			pairSize = 2;
		creatingMainPend_deq(pairSize);
		insertion_deq(pairSize);
		this->_deqMain.clear();
		this->_deqPend.clear();
		this->_deqNotParticiping.clear();
		pairSize /= 2;
	}
}

static void swapPairs_deq(std::deque<int>::iterator it, int power)
{
	for (int i = 0; i < power; i++)
	{
		std::iter_swap(it, (it + power));
		it++;
	}
}

//pairing numbers recursively and doing a first sort
//careful not to take the last numbers in case of an odd total
void Pmergeme::pairUp_deq(int power)
{
	int pairSize = 2 * power;
	int nbPairs = this->_size / pairSize;

	if (nbPairs < 1)
	{
		this->_maxPairSize = pairSize / 4;
		return ;
	}
	
	std::deque<int>::iterator it;
	std::deque<int>::iterator end = this->_deqNumbers.begin() + nbPairs * pairSize;

	for(it = this->_deqNumbers.begin(); it != end; std::advance(it, pairSize))
	{
		if (*(it + power - 1) > *(it + pairSize - 1))
			swapPairs_deq(it, power);
	}

	pairUp_deq(power * 2);
}

void Pmergeme::creatingMainPend_deq(int pairSize)
{
	int i = 0;
	int j = 0;

	while (i < (pairSize * 2))
	{
		this->_deqMain.push_back(this->_deqNumbers[i]);
		i++;
	}
	if ((i + pairSize) <= this->_size)
	{
		while (j < pairSize)
		{
			this->_deqPend.push_back(this->_deqNumbers[i]);
			j++;
			i++;
		}
	}
	while (i + (pairSize * 2) <= this->_size)
	{
		j = 0;
		while (j < pairSize)
		{
			this->_deqMain.push_back(this->_deqNumbers[i]);
			j++;
			i++;
		}
		j = 0;
		while (j < pairSize)
		{
			this->_deqPend.push_back(this->_deqNumbers[i]);
			j++;
			i++;
		}
	}
	while (i < this->_size)
	{
		this->_deqNotParticiping.push_back(this->_deqNumbers[i]);
		i++;
	}
}

void Pmergeme::insertion_deq(int pairSize)
{
	int		toInsert = 0;
	int		comparaison = 0;
	int		i = 3;
	int 	j;
	int		index = jacobsthalNumber(i);
	int		previousIndex = 1;
	size_t	position;

	std::deque<int>::iterator inserting_start;
	std::deque<int>::iterator inserting_end;
	std::deque<int>::iterator place;

	while (this->_deqPend.empty() == false)
	{
		position = (index + (index - 1)) * pairSize - 1;
		if (position <= this->_deqNumbers.size() - this->_deqNotParticiping.size())
			toInsert = this->_deqNumbers[position];
		else
			toInsert = this->_deqPend.back();
		inserting_end = std::find(this->_deqPend.begin(), this->_deqPend.end(), toInsert);
		if (inserting_end != this->_deqPend.end())	
			inserting_end++;
		inserting_start = inserting_end - pairSize;

		j = 0;
		while ((index - j) > previousIndex && inserting_start >= this->_deqPend.begin())
		{	
			if (toInsert == this->_deqNumbers.back() || position + pairSize >= this->_deqNumbers.size() - this->_deqNotParticiping.size())
			{
				comparaison = this->_deqMain.back();
				place = this->_deqMain.end();
			}
			else
			{
				comparaison = this->_deqNumbers[position + pairSize];
				place = std::find(this->_deqMain.begin(), this->_deqMain.end(), comparaison) + 1;
			}
			
			if (comparaison == this->_deqMain.back() && comparaison > toInsert)
				place -= pairSize;
			while ((place - pairSize) >= this->_deqMain.begin() && *(place - 1) > toInsert && place != this->_deqMain.end())
				place -= pairSize;
			if (place < this->_deqMain.begin())
				place = this->_deqMain.begin();
			
			this->_deqMain.insert(place, inserting_start, inserting_end);
			inserting_start -= pairSize;
			inserting_end -= pairSize;
			if (inserting_start >= this->_deqPend.begin())
				toInsert = *(inserting_end - 1);
			j++;
		}

		if (std::distance(this->_deqPend.begin(), (this->_deqPend.begin() + j * pairSize)) >= (long)this->_deqPend.size())
		{
			this->_deqPend.clear();
			break ;
		}
		else		
			this->_deqPend.erase(this->_deqPend.begin(), (this->_deqPend.begin() + j * pairSize));

		i++;
		previousIndex = index;
		index = jacobsthalNumber(i);
	}
	this->_deqNumbers = this->_deqMain;
	if (this->_deqNotParticiping.empty() == false)
		this->_deqNumbers.insert(this->_deqNumbers.end(), this->_deqNotParticiping.begin(), this->_deqNotParticiping.end());
}

//Exceptions
const char* Pmergeme::WrongInputException::what() const throw()
{
	return ("Error: wrong input");
}

const char* Pmergeme::SortingErrorException::what() const throw()
{
	return ("Error: sorting error");
}


