#pragma once

#include <iostream>
#include <vector>
#include <deque>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <iterator>
#include <ctime>
#include <iomanip>

//Color
# define RESET			"\033[0m"
# define BLACK			"\033[30m"
# define RED			"\033[31m"
# define GREEN			"\033[32m"
# define YELLOW			"\033[33m"
# define BLUE			"\033[34m"
# define MAGENTA		"\033[35m"
# define CYAN			"\033[36m"
# define WHITE			"\033[37m"
# define BOLD			"\033[1m"
# define B_BLACK		"\033[1m\033[30m"
# define B_RED			"\033[1m\033[31m"
# define B_GREEN		"\033[1m\033[32m"
# define B_YELLOW		"\033[1m\033[33m"
# define B_BLUE			"\033[1m\033[34m"
# define B_MAGENTA		"\033[1m\033[35m"
# define B_CYAN			"\033[1m\033[36m"
# define B_WHITE		"\033[1m\033[37m"

class Pmergeme
{
	private:
	//common
		int					_size;
		int					_maxPairSize;
	//vector
		std::vector<int>	_vecNumbers;
		std::vector<int>	_vecMain;
		std::vector<int>	_vecPend;
		std::vector<int>	_vecNotParticiping;
		double				_vecTime;
	//deque
		std::deque<int>		_deqNumbers;
		std::deque<int>		_deqMain;
		std::deque<int>		_deqPend;
		std::deque<int>		_deqNotParticiping;
		double				_deqTime;
	
		void				sortVect();
		void				pairUp_vec(int n);
		void 				creatingMainPend_vec(int pairSize);
		void				insertion_vec(int pairSize);
		void				sortDeq();
		void				pairUp_deq(int n);
		void 				creatingMainPend_deq(int pairSize);
		void				insertion_deq(int pairSize);

	public:
	//Canonical form
		Pmergeme();
		Pmergeme(Pmergeme &copy);
		Pmergeme& operator=(Pmergeme &copy);
		~Pmergeme();

		Pmergeme(int ac);
	
	//Getter and Setter
		void setTime(int i, double time);

	//Methods
		void	initialize(char **argv);
		void	sort(int i);
		void	display(char **argv);

	//Exceptions
		class WrongInputException : public std::exception
		{
			virtual const char *what() const throw();
		};
		class SortingErrorException: public std::exception
		{
			virtual const char *what() const throw();
		};
	
	//Utils
		bool isSorted(int i);
};