#include "BitcoinExchange.hpp"

int main(int ac, char **av)
{
	BitcoinExchange bce;

	if (ac != 2)
	{
		std::cerr << "Error: Wrong argument\nNeed: ./btc input.txt" << std::endl;
		return (1);
	}
	try
	{
		data_parsing(bce);
	}
	catch(const std::exception& e)
	{
		std::cerr << e.what() << '\n';
		return (1);
	}
	parsing(av[1], bce);

	return (0);
}