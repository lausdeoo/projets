#include "BitcoinExchange.hpp"

//compare dates to find the closer one (but smaller if the exact date is not here)
//compare aaa-mm in string then dd in int ?
float exchange(BitcoinExchange &bce, std::map<std::string, float> input)
{
	float changed;
	std::map<std::string, float> data = bce.getMap();
	std::map<std::string, float>::iterator itd;
	std::map<std::string, float>::iterator iti = input.begin();
	int data_day;
	int input_day = atof(iti->first.substr(8).c_str());

	for (itd = data.begin(); itd != data.end(); itd++)
	{
		if (!itd->first.compare(0, 8, iti->first, 0, 8))
		{
			data_day = atof(itd->first.substr(9).c_str());
			// std::cout << "input day: " << input_day << " ; data_day: " << data_day << std::endl;
			while (data_day < input_day)
			{
				itd++;
				data_day = atof(itd->first.substr(8).c_str());
			}
			if (data_day > input_day)
			{
				itd--;
				// std::cout << "data_date: " << itd->first << std::endl;
			}
			// std::cout << "data_date: " << itd->first << std::endl;
			break ;
		}
	}
	if (itd == data.end())
		return (-1);
	changed = iti->second * itd->second;
	// std::cout << "data day: " << itd->first << " ; input day: " << iti->first << std::endl;
	return (changed);
}

void print_exchanges(BitcoinExchange &bce, std::map<std::string, float> input)
{
	std::map<std::string, float>::iterator it = input.begin();
	float changed;

	if (it->first == "WRONG_VALUE")
	{
		if (it->second < 0)
			std::cout << "Error: not a positive number."<< std::endl;
		if (it->second > 1000)
			std::cout << "Error: too large a number." << std::endl;			
	}
	else if (it->second == WRONG_INPUT || it->second == WRONG_DATE)
			std::cout << "Error: wrong input => " << it->first << std::endl;
	else
	{
		changed = exchange(bce, input);
		if (changed == -1)
		{
			std::cout << "Error: No data found." << std::endl;
			return ;
		}
		std::cout << it->first << " => " << it->second << " = " << changed << std::endl;
	}
}