#include "BitcoinExchange.hpp"

//Canonical Form
BitcoinExchange::BitcoinExchange()
{}

BitcoinExchange::BitcoinExchange(BitcoinExchange const &copy): _data(copy._data)
{}

BitcoinExchange& BitcoinExchange::operator=(BitcoinExchange const &copy)
{
	if (this != &copy)
		this->_data = copy._data;
	return (*this);
}

BitcoinExchange::~BitcoinExchange()
{}

//Member Functions
void BitcoinExchange::setMap(std::string str, float f)
{
	this->_data.insert(std::pair<std::string, float>(str, f));
}

std::map<std::string, float>	BitcoinExchange::getMap(void)
{
	return (this->_data);
}

//Exceptions
const char* BadDataCSVException::what() const throw()
{
	return "Bad data in .csv file";
}