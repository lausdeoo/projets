#include "BitcoinExchange.hpp"

//verify the dates to see if they exist and if they are inside the scope of the .csv
//30 days in april, june, september and november
//31 days in january, march, may, july, august, october and december
//29 days in february in leap year, 28 otherwise
//leap year: 
	//divided by 4 but not 100
	//divided by 400 
int date_validation(std::string date)
{
	int year;
	int month;
	int day;
	bool leap = false;

	year = atoi(date.substr(0, 4).c_str());
	month = atoi(date.substr(5, 2).c_str());
	day = atoi(date.substr(8, 2).c_str());

	if (year <= 0 || year < 2009 || year > 2022)
		return (1);
	if (month <= 0 || month > 12)
		return (1);
	
	if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
		leap = true;
	if (day > 31 || day <= 0)
		return (1);
	if (month == 4 || month == 6 || month == 9 || month == 11)
		if (day > 30)
			return (1);
	if (month == 2)
	{
		if (leap && day > 29)
			return (1);
		if (!leap && day > 28)
			return (1);
	}
	return (0);
}

int value_verification(std::string line, float value)
{
	if (value < 0 || value > 1000 || (value == 0 && isalpha(line[1])))
		return (1);
	return (0);
}

int line_verification(std::string line)
{
	if (line.length() < 12)
		return (1);
	if (line[10] != ' ' || line[11] != '|' || line[12] != ' ')
		return (1);
	if (line[4] != '-' || line[7] != '-')
		return (1);
	return (0);
}

std::map<std::string, float> get_input_data(std::string line)
{
	std::map<std::string, float> input;
	std::string date;
	std::string rate;
	float		nb;

	if (line_verification(line))
	{
		input.insert(std::pair<std::string, float>(line, WRONG_INPUT));
		return (input);
	}

	date = line.substr(0, 10);
	rate = line.substr(12);
	nb = atof(rate.c_str());

	if(date_validation(date))
		input.insert(std::pair<std::string, float>(date, WRONG_DATE));
	else if(value_verification(rate, nb))
		input.insert(std::pair<std::string, float>("WRONG_VALUE", nb));
	else
		input.insert(std::pair<std::string, float>(date, nb));
	return (input);
}

void	parsing(char *file, BitcoinExchange &bce)
{
	std::map<std::string, float> input;
	std::ifstream infile;
	std::string	line;

	infile.open(file);
	if (!infile.is_open())
		throw std::runtime_error("Error: Cannot open file");
	while (getline(infile, line))
	{
		if (line != "date | value")
		{
			input = get_input_data(line);
			print_exchanges(bce, input);
			input.clear();
		}
	}
}
