#include "BitcoinExchange.hpp"

int data_line_verification(std::string line)
{
	if (line.length() < 10)
		return (1);
	if (line[10] != ',' || line[4] != '-' || line[7] != '-')
		return (1);
	return (0);
}

//divise line in date and exchange rate
//line format: aaaa-mm-dd,rate
void	get_data(std::string line, BitcoinExchange &bce)
{
	std::string date;
	std::string rate;
	float		nb;

	if (data_line_verification(line))
		throw BadDataCSVException();
	date = line.substr(0, 10);
	rate = line.substr(11);
	nb = atof(rate.c_str());

	bce.setMap(date, nb);
}

void data_parsing(BitcoinExchange &bce)
{
	std::string line;
	std::ifstream data_file;

	data_file.open("data.csv");
	if (!data_file.is_open())
		throw std::runtime_error("Error: Cannot open file");
	while (getline(data_file, line))
	{
		if (line != "date,exchange_rate")
				get_data(line, bce);
	}
}
