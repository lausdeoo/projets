#pragma once

#include <iostream>
#include <map>
#include <fstream>
#include <string>
#include <cstdlib>

#define WRONG_DATE -1
#define WRONG_INPUT -2

class BitcoinExchange
{
	private:
		std::map<std::string, float>	_data;

	public:
	//Canonical Form
		BitcoinExchange();
		BitcoinExchange(BitcoinExchange const &copy);
		BitcoinExchange& operator=(BitcoinExchange const &copy);
		virtual ~BitcoinExchange();
	//Member Functions
		void	setMap(std::string str, float f);
		std::map<std::string, float>	getMap(void);
};

//Data base parsing
void data_parsing(BitcoinExchange &bte);

//File parsing
void	parsing(char *file, BitcoinExchange &bce);

//Execution
void print_exchanges(BitcoinExchange &bce, std::map<std::string, float> input);

class BadDataCSVException : public std::exception
{
	public:
		virtual const char *what() const throw();
};